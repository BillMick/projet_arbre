# tree-management-client

#### 介绍

#### 软件架构
tree-management-client是基于JavaFx开发的客户端应用，
页面UI由fxml文件编写，利用HBox(水平控件布局)和VHox(垂直控件布局)实现页面
的基本布局；通过FXMLLoader加载fxml文件，读取文件中的控件节点绘制页面；
客户端所有的请求通过UI线程调用后端接口；ObjectMapper负责Json的序列化和反序列化
（客户端->后端，将JavaBean序列化成Json，后端->客户端将Json反序列化成JavaBean）


#### 安装教程

1.  jdk1.8
2.  maven

#### 使用说明

1.  LoginView是客户端的主入口，启动打开登录页面
