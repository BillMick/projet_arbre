package cn.individual.treemanagement.client.api;

import cn.individual.treemanagement.client.pojo.entity.SystemDues;
import cn.individual.treemanagement.client.pojo.vo.SystemUserDuesVO;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import cn.individual.treemanagement.client.config.InitConfigurer;
import cn.individual.treemanagement.client.pojo.form.DuesForm;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static cn.individual.treemanagement.client.common.UrlPath.*;

/**
 * @author li
 * @date create in 2025/1/17 21:50
 **/
public class DuesApi {

    private final ObjectMapper objectMapper;

    public DuesApi() {
        objectMapper = InitConfigurer.objectMapper;
    }

    public void donateDues(DuesForm form) {
        JsonNode formNode = objectMapper.valueToTree(form);
        Request.postRequest(domain + donateApi, formNode);
    }

    public Double yearDues() {
        JsonNode data = Request.getRequest(domain + yearDonateApi, new HashMap<>());
        return objectMapper.convertValue(data, Double.class);
    }

    public List<SystemUserDuesVO> getUserDuesList(LocalDate startDate, LocalDate endDate, Integer paid) {
        Map<String, Object> form = new HashMap<>();
        form.put("startDate", startDate);
        form.put("endDate", endDate);
        form.put("paid", paid);
        JsonNode data = Request.getRequest(domain + userDuesApi, form);
        return objectMapper.convertValue(data, objectMapper.getTypeFactory().constructCollectionType(List.class, SystemUserDuesVO.class));
    }

    public List<SystemDues> getDuesList(LocalDate startDate, LocalDate endDate) {
        MultiValueMap<String, Object> form = new LinkedMultiValueMap<>();
        form.add("startDate", startDate);
        form.add("endDate", endDate);
        JsonNode data = Request.postRequest(domain + duesApi, form);
        return objectMapper.convertValue(data, objectMapper.getTypeFactory().constructCollectionType(List.class, SystemDues.class));
    }

    public List<SystemUserDuesVO> getSelfDuesList(LocalDate startDate, LocalDate endDate) {
        Map<String, Object> form = new HashMap<>();
        form.put("startDate", startDate);
        form.put("endDate", endDate);
        JsonNode data = Request.getRequest(domain + selfDuesApi, form);
        return objectMapper.convertValue(data, objectMapper.getTypeFactory().constructCollectionType(List.class, SystemUserDuesVO.class));
    }
}
