package cn.individual.treemanagement.client.view.login;

import cn.individual.treemanagement.client.api.UserApi;
import cn.individual.treemanagement.client.common.Constants;
import cn.individual.treemanagement.client.config.InitConfigurer;
import cn.individual.treemanagement.client.control.ErrorDialog;
import cn.individual.treemanagement.client.pojo.vo.LoginResult;
import cn.individual.treemanagement.client.util.AESUtil;
import cn.individual.treemanagement.client.util.LocalCacheUtil;
import javafx.application.Platform;
import javafx.concurrent.Task;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.concurrent.ExecutionException;

/**
 * @author li
 * @date create in 2025/1/21 16:11
 **/
public class LoginController {

    @FXML
    public Label usernameLab;

    @FXML
    public Label passwordLab;

    @FXML
    public TextField usernameText;

    @FXML
    public PasswordField passwordText;

    @FXML
    public Button loginButton;

    @FXML
    public Button registerButton;

    private final UserApi userApi;

    public LoginController() {
        userApi = new UserApi();
    }

    @FXML
    protected void login() throws ExecutionException, InterruptedException {
        Platform.runLater(loginTask());
    }

    @FXML
    protected void register() {
        this.redirectToRegister();
    }

    private Task<LoginResult> loginTask() {
        Task<LoginResult> loginTask = new Task<LoginResult>() {
            @Override
            protected LoginResult call() throws Exception {
                return userApi.login(usernameText.getText(), AESUtil.encrypt(passwordText.getText()));
            }
        };
        loginTask.setOnSucceeded(event -> {
            LoginResult loginResult = (LoginResult) event.getSource().getValue();
            LocalCacheUtil.set(Constants.LOGIN_USER, loginResult);
            this.redirectToHome();
        });
        return loginTask;
    }

    private void redirectToHome() {
        try {
            Stage stage = (Stage) loginButton.getScene().getWindow();
            stage.hide();
            Parent root = FXMLLoader.load(getClass().getClassLoader().getResource("view/home/HomeController.fxml"));
            Stage homeStage = new Stage();
            homeStage.setTitle("Tree Management");
            Scene scene = new Scene(root, 1200, 800);
            homeStage.setScene(scene);
            homeStage.show();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    private void redirectToRegister() {
        try {
            Parent root = FXMLLoader.load(getClass().getClassLoader().getResource("view/login/RegisterController.fxml"));
            Stage registerStage = new Stage();
            registerStage.setTitle("Register");
            Scene scene = new Scene(root, 500, 600);
            registerStage.setScene(scene);
            registerStage.show();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
