package cn.individual.treemanagement.client.api;

import cn.individual.treemanagement.client.pojo.vo.SystemUserVO;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import cn.individual.treemanagement.client.util.LocalStorage;
import cn.individual.treemanagement.client.pojo.RoleEnum;
import cn.individual.treemanagement.client.config.InitConfigurer;
import cn.individual.treemanagement.client.pojo.form.DuesForm;
import cn.individual.treemanagement.client.pojo.form.LoginForm;
import cn.individual.treemanagement.client.pojo.form.PasswordForm;
import cn.individual.treemanagement.client.pojo.form.UserForm;
import cn.individual.treemanagement.client.pojo.vo.LoginResult;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;

import static cn.individual.treemanagement.client.common.UrlPath.*;
import static cn.individual.treemanagement.client.common.UrlPath.changePasswordApi;

/**
 * @author li
 * @date create in 2025/1/17 21:14
 **/
public class UserApi {

    private final ObjectMapper objectMapper;

    public UserApi() {
        objectMapper = InitConfigurer.objectMapper;
    }

    public LoginResult login(String username, String password) {
        LoginForm loginForm = new LoginForm();
        loginForm.setUsername(username);
        loginForm.setPassword(password);
        JsonNode form = objectMapper.valueToTree(loginForm);
        JsonNode data = Request.postRequest(domain + loginApi, form);
        LoginResult loginResult = objectMapper.convertValue(data, LoginResult.class);
        LocalStorage.accessToken = loginResult.getAccessToken();
        LocalStorage.role = RoleEnum.getRoleByCode(loginResult.getRoleId());
        return loginResult;
    }

    public SystemUserVO loginUserInfo() {
        JsonNode data = Request.getRequest(domain + loginInfoApi, new HashMap<>());
        return objectMapper.convertValue(data, SystemUserVO.class);
    }

    public List<SystemUserVO> getUserList(LocalDate startDate, LocalDate endDate, Integer status, String keyword) {
        MultiValueMap<String, Object> form = new LinkedMultiValueMap<>();
        form.add("startDate", startDate);
        form.add("endDate", endDate);
        form.add("status", status);
        form.add("keyword", keyword);
        JsonNode data = Request.postRequest(domain + userApi, form);
        return objectMapper.convertValue(data, objectMapper.getTypeFactory().constructCollectionType(List.class, SystemUserVO.class));
    }

    public void logout() {
        Request.postRequest(domain + logoutApi, objectMapper.createObjectNode());
    }

    public void registerUser(UserForm userForm) {
        JsonNode form = objectMapper.valueToTree(userForm);
        Request.postRequest(domain + registerApi, form);
    }

    public void becomeMember() {
        Request.postRequest(domain + becomeMemberApi, objectMapper.createObjectNode());
    }

    public void renewal(DuesForm form) {
        JsonNode formData = objectMapper.valueToTree(form);
        Request.postRequest(domain + renewalApi, formData);
    }

    public void changePassword(PasswordForm form) {
        JsonNode formData = objectMapper.valueToTree(form);
        Request.postRequest(domain + changePasswordApi, formData);
    }

    public boolean isFullPayDues() {
        JsonNode data = Request.getRequest(domain + isFullPay, new HashMap<>());
        return objectMapper.convertValue(data, Boolean.class);
    }
}
