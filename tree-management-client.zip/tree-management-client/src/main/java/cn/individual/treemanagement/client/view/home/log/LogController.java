package cn.individual.treemanagement.client.view.home.log;

import cn.individual.treemanagement.client.api.AdminApi;
import cn.individual.treemanagement.client.config.InitConfigurer;
import cn.individual.treemanagement.client.pojo.entity.SystemLog;
import javafx.application.Platform;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.concurrent.Task;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

/**
 * @author li
 * @date create in 2025/1/22 13:58
 **/
public class LogController {
    @FXML
    public DatePicker startDatePicker;

    @FXML
    public DatePicker endDatePicker;

    @FXML
    public Button queryButton;

    @FXML
    public TableView<SystemLog> systemLogTableView;

    @FXML
    public TableColumn<SystemLog, String> hostColumn;

    @FXML
    public TableColumn<SystemLog, String> urlColumn;

    @FXML
    public TableColumn<SystemLog, Integer> responseStatusColumn;

    @FXML
    public TableColumn<SystemLog, String> tokenColumn;

    @FXML
    public TableColumn<SystemLog, LocalDateTime> createTimeColumn;

    private ObjectProperty<LocalDate> startDate;

    private ObjectProperty<LocalDate> endDate;

    private AdminApi adminApi;

    private List<SystemLog> systemLogList;

    @FXML
    public void systemLogList(ActionEvent actionEvent) {
        Platform.runLater(systemLogListTask());
    }

    @FXML
    public void initialize() {
        this.startDate = new SimpleObjectProperty<>();
        this.endDate = new SimpleObjectProperty<>();
        this.adminApi = new AdminApi();
        this.systemLogList = adminApi.systemLogList(null, null);
        this.bindQueryEvent();
        this.setSystemLogTableView();
        this.setTableColumns();
    }

    public void bindQueryEvent() {
        startDatePicker.valueProperty().bindBidirectional(startDate);
        endDatePicker.valueProperty().bindBidirectional(endDate);
    }

    public void setSystemLogTableView() {
        ObservableList<SystemLog> observableList = FXCollections.observableList(systemLogList);
        systemLogTableView.setItems(observableList);
    }

    public void setTableColumns() {
        hostColumn.setCellValueFactory(new PropertyValueFactory<>("host"));
        urlColumn.setCellValueFactory(new PropertyValueFactory<>("url"));
        responseStatusColumn.setCellValueFactory(new PropertyValueFactory<>("responseStatus"));
        tokenColumn.setCellValueFactory(new PropertyValueFactory<>("token"));
        createTimeColumn.setCellValueFactory(new PropertyValueFactory<>("createTime"));
    }

    private Task<List<SystemLog>> systemLogListTask() {
        Task<List<SystemLog>> systemLogListTask = new Task<List<SystemLog>>() {
            @Override
            protected List<SystemLog> call() throws Exception {
                return adminApi.systemLogList(startDate.getValue(), endDate.getValue());
            }
        };
        systemLogListTask.setOnSucceeded(event -> {
            systemLogTableView.getItems().clear();
            systemLogTableView.getItems().addAll(systemLogListTask.getValue());
        });
        return systemLogListTask;
    }

}
