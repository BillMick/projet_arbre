package cn.individual.treemanagement.client.view.home;

import cn.individual.treemanagement.client.api.UserApi;
import cn.individual.treemanagement.client.control.TipsDialog;
import cn.individual.treemanagement.client.pojo.RoleEnum;
import cn.individual.treemanagement.client.pojo.vo.SystemUserVO;
import cn.individual.treemanagement.client.util.LocalCacheUtil;
import javafx.application.Platform;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;
import javafx.scene.shape.Circle;
import javafx.stage.Stage;

import java.io.IOException;

/**
 * @author li
 * @date create in 2025/1/22 9:37
 **/
public class HomeController {

    private UserApi userApi;

    @FXML
    public ImageView headerImage;

    @FXML
    public Label usernameLab;

    @FXML
    public Button navTreeButton;

    @FXML
    public Button navOutstandingButton;

    @FXML
    public Button navActivityButton;

    @FXML
    public Button navDuesButton;

    @FXML
    public Button navUserButton;

    @FXML
    public Button navVoteButton;

    @FXML
    public Button navPayButton;

    @FXML
    public Button navLogButton;

    @FXML
    public Button logoutButton;

    @FXML
    public Pane contextPane;

    @FXML
    public void initialize() {
        this.userApi = new UserApi();
        SystemUserVO systemUserVO = userApi.loginUserInfo();
        usernameLab.setText(systemUserVO.getUsername());
        if (systemUserVO.getRoleId().equals(RoleEnum.Guest.getCode())) {
            navActivityButton.setManaged(false);
            navDuesButton.setManaged(false);
            navUserButton.setManaged(false);
            navVoteButton.setManaged(false);
        }
        this.setHeaderImage();
        if(!systemUserVO.getRoleId().equals(RoleEnum.Admin.getCode())) {
            navLogButton.setManaged(false);
        }
        navTreeButton.fire();
    }

    @FXML
    public void loadTreeView(ActionEvent actionEvent) {
        Platform.runLater(()->{
            Parent root = this.getRoot("/tree/TreeController.fxml");
            ObservableList<Node> children = contextPane.getChildren();
            children.clear();
            children.add(root);
        });
    }

    @FXML
    public void loadOutstandingTreeView(ActionEvent actionEvent) {
        Platform.runLater(()->{
            Parent root = this.getRoot("/outstanding/OutstandingController.fxml");
            ObservableList<Node> children = contextPane.getChildren();
            children.clear();
            children.add(root);
        });
    }

    @FXML
    public void loadActivityView(ActionEvent actionEvent) {
        Platform.runLater(()->{
            Parent root = this.getRoot("/activity/ActivityController.fxml");
            ObservableList<Node> children = contextPane.getChildren();
            children.clear();
            children.add(root);
        });
    }

    @FXML
    public void loadDuesView(ActionEvent actionEvent) {
        Platform.runLater(()->{
            Parent root = this.getRoot("/dues/DuesController.fxml");
            ObservableList<Node> children = contextPane.getChildren();
            children.clear();
            children.add(root);
        });
    }

    @FXML
    public void loadUserView(ActionEvent actionEvent) {
        Platform.runLater(()->{
            Parent root = this.getRoot("/user/UserController.fxml");
            ObservableList<Node> children = contextPane.getChildren();
            children.clear();
            children.add(root);
        });
    }

    @FXML
    public void loadVoteView(ActionEvent actionEvent) {
        Platform.runLater(()->{
            Parent root = this.getRoot("/vote/VoteController.fxml");
            ObservableList<Node> children = contextPane.getChildren();
            children.clear();
            children.add(root);
        });
    }

    @FXML
    public void loadPaidView(ActionEvent actionEvent) {
        Platform.runLater(()->{
            Parent root = this.getRoot("/paid/PaidController.fxml");
            ObservableList<Node> children = contextPane.getChildren();
            children.clear();
            children.add(root);
        });
    }

    @FXML
    public void loadLogView(ActionEvent actionEvent) {
        Platform.runLater(()->{
            Parent root = this.getRoot("/log/LogController.fxml");
            ObservableList<Node> children = contextPane.getChildren();
            children.clear();
            children.add(root);
        });
    }

    @FXML
    public void logout(ActionEvent actionEvent) {
        TipsDialog tipsDialog = new TipsDialog("Logout", "Are you sure you want to logout?");
        ButtonType buttonType = tipsDialog.showAndWait();
        if(buttonType == ButtonType.OK) {
            userApi.logout();
            LocalCacheUtil.clear();
            this.redirectToLogin();
        }
    }

    private void setHeaderImage() {
        Image image = new Image(getClass().getClassLoader().getResourceAsStream("asset/header.png"));
        headerImage.setImage(image);
        Circle circleClip = new Circle(50, 50, 50);
        headerImage.setClip(circleClip);
    }

    private Parent getRoot(String path) {
        try {
            return FXMLLoader.load(getClass().getClassLoader().getResource("view/home" + path));
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    private void redirectToLogin() {
        try {
            Stage homeStage = (Stage) logoutButton.getScene().getWindow();
            homeStage.hide();
            Parent root = FXMLLoader.load(getClass().getClassLoader().getResource("view/login/LoginController.fxml"));
            Stage loginStage = new Stage();
            loginStage.setTitle("Login");
            Scene scene = new Scene(root, 600, 400);
            loginStage.setScene(scene);
            loginStage.show();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
