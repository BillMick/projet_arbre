package cn.individual.treemanagement.client.view.home.vote;

import cn.individual.treemanagement.client.api.VoteApi;
import cn.individual.treemanagement.client.config.InitConfigurer;
import cn.individual.treemanagement.client.pojo.vo.SystemVoteVO;
import javafx.application.Platform;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.concurrent.Task;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

/**
 * @author li
 * @date create in 2025/1/22 13:58
 **/
public class VoteController {
    @FXML
    public DatePicker startDatePicker;

    @FXML
    public DatePicker endDatePicker;

    @FXML
    public Button queryButton;

    @FXML
    public TableView<SystemVoteVO> voteUserTableView;

    @FXML
    public TableColumn<SystemVoteVO, String> usernameColumn;

    @FXML
    public TableColumn<SystemVoteVO, String> voteUsername;

    @FXML
    public TableColumn<SystemVoteVO, LocalDateTime> createTimeColumn;

    @FXML
    public TableColumn<SystemVoteVO, LocalDateTime> updateTimeColumn;

    private VoteApi voteApi;

    private List<SystemVoteVO> voteUserList;

    private ObjectProperty<LocalDate> startDate;

    private ObjectProperty<LocalDate> endDate;


    @FXML
    public void voteUserList(ActionEvent actionEvent) {
        Platform.runLater(voteUserListTask());
    }

    @FXML
    public void initialize() {
        this.voteApi = new VoteApi();
        voteUserList = voteApi.voteUserList(null, null);
        this.bindQueryEvent();
        this.setVoteUserTableView();
        this.setTableColumns();
    }

    private void bindQueryEvent() {
        startDate = new SimpleObjectProperty<>();
        endDate = new SimpleObjectProperty<>();
        startDatePicker.valueProperty().bindBidirectional(startDate);
        endDatePicker.valueProperty().bindBidirectional(endDate);
    }

    private void setVoteUserTableView() {
        ObservableList<SystemVoteVO> observableList = FXCollections.observableList(voteUserList);
        voteUserTableView.setItems(observableList);
    }

    private void setTableColumns() {
        usernameColumn.setCellValueFactory(new PropertyValueFactory<>("username"));
        voteUsername.setCellValueFactory(new PropertyValueFactory<>("voteUsername"));
        createTimeColumn.setCellValueFactory(new PropertyValueFactory<>("createTime"));
        updateTimeColumn.setCellValueFactory(new PropertyValueFactory<>("updateTime"));
    }

    private Task<List<SystemVoteVO>> voteUserListTask() {
        Task<List<SystemVoteVO>> voteUserListTask = new Task<List<SystemVoteVO>>() {
            @Override
            protected List<SystemVoteVO> call() throws Exception {
                return voteApi.voteUserList(startDatePicker.getValue(), endDatePicker.getValue());
            }
        };
        voteUserListTask.setOnSucceeded(event -> {
            voteUserTableView.getItems().clear();
            voteUserTableView.getItems().addAll(voteUserListTask.getValue());
        });
        return voteUserListTask;
    }
}
