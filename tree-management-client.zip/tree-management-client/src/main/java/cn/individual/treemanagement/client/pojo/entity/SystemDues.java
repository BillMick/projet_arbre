package cn.individual.treemanagement.client.pojo.entity;

import lombok.Data;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * @author li
 * @date create in 2025/1/13 17:28
 **/
@Data
public class SystemDues implements Serializable {
    private Integer id;

    private Double dues;

    private Integer year;

    private LocalDateTime createTime;

    private LocalDateTime updateTime;
}
