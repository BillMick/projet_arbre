package cn.individual.treemanagement.client.control;

import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Dialog;
import javafx.scene.control.DialogPane;

import java.util.Optional;

/**
* @author li
* @date create in 2025/1/24 10:11
**/
public class TipsDialog {
    private Dialog<ButtonType> dialog;

    private DialogPane dialogPane;

    private Button okButton;

    private Button cancelButton;

    private String content;

    private String title;

    public TipsDialog(String content) {
        this.content = content;
        this.title = "Tips";
    }

    public TipsDialog(String title, String content) {
        this.title = title;
        this.content = content;
    }

    private void setOkButtonAction() {
        okButton.setOnAction((event) -> {
            dialog.close();
        });
    }

    private void setCancelButtonAction() {
        cancelButton.setOnAction((event) -> {
            dialog.close();
        });
    }

    public Optional<ButtonType> show() {
        dialog = new Dialog<>();
        dialog.setHeaderText(title);
        dialog.setContentText(content);
        dialogPane = dialog.getDialogPane();
        dialogPane.getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);
        okButton = (Button) dialogPane.lookupButton(ButtonType.OK);
        cancelButton = (Button) dialogPane.lookupButton(ButtonType.CANCEL);
        this.setCancelButtonAction();
        this.setOkButtonAction();
        dialog.setOnCloseRequest(event -> {
            dialog.close();
        });
        return dialog.showAndWait();
    }

    public ButtonType showAndWait() {
        Optional<ButtonType> show = this.show();
        return show.orElse(ButtonType.CANCEL);
    }
}
