package cn.individual.treemanagement.client.api;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import cn.individual.treemanagement.client.config.InitConfigurer;
import cn.individual.treemanagement.client.pojo.form.ActivityForm;
import cn.individual.treemanagement.client.pojo.vo.ActivityVO;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static cn.individual.treemanagement.client.common.UrlPath.*;

/**
 * @author li
 * @date create in 2025/1/18 18:22
 **/
public class ActivityApi {

    private final ObjectMapper objectMapper;

    public ActivityApi() {
        objectMapper = InitConfigurer.objectMapper;
    }

    public List<ActivityVO> activityList(LocalDate startDate, LocalDate endDate, String keyword) {
        Map<String, Object> params = new HashMap<>();
        params.put("startDate", startDate);
        params.put("endDate", endDate);
        params.put("keyword", keyword);
        JsonNode data = Request.getRequest(domain + activityListApi, params);
        return objectMapper.convertValue(data, objectMapper.getTypeFactory().constructCollectionType(List.class, ActivityVO.class));
    }

    public void organizeActivity(ActivityForm form) {
        JsonNode formData = objectMapper.convertValue(form, JsonNode.class);
        Request.postRequest(domain + organizeActivityApi, formData);
    }
}
