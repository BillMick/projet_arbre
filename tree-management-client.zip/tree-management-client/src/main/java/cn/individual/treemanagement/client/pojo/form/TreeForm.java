package cn.individual.treemanagement.client.pojo.form;

import lombok.Data;

import java.io.Serializable;

/**
 * @author li
 * @date create in 2025/1/14 11:40
 **/
@Data
public class TreeForm implements Serializable {
    /**
     * 属
     */
    private String genus;
    /**
     * 种
     */
    private String species;
    /**
     * 常用名
     */
    private String commonName;
    /**
     * 胸围
     */
    private Double bustSize;
    /**
     * 高度
     */
    private Double height;
    /**
     * 发育阶段
     */
    private String developmentalStage;
    /**
     * 经度
     */
    private Double longitude;
    /**
     * 纬度
     */
    private Double latitude;
}
