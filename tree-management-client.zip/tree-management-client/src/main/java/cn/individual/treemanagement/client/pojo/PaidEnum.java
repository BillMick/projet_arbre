package cn.individual.treemanagement.client.pojo;

import lombok.Getter;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public enum PaidEnum {

    Unpaid(0, "未支付"),
    Paid(1, "支付"),
    Donation(2, "捐赠");

    @Getter
    private Integer code;

    @Getter
    private String name;

    PaidEnum(Integer code, String name) {
        this.code = code;
        this.name = name;
    }

    public static PaidEnum getEnum(Integer code) {
        for (PaidEnum e : PaidEnum.values()) {
            if (e.getCode().equals(code)) {
                return e;
            }
        }
        return null;
    }

    public static List<String> paidEnumNames() {
        PaidEnum[] paidEnums = PaidEnum.values();
        return Arrays.stream(paidEnums).map(PaidEnum::name).collect(Collectors.toList());
    }
}
