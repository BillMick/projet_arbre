package cn.individual.treemanagement.client.view.home.outstanding;

import cn.individual.treemanagement.client.api.AdminApi;
import cn.individual.treemanagement.client.api.TreeApi;
import cn.individual.treemanagement.client.common.Constants;
import cn.individual.treemanagement.client.config.InitConfigurer;
import cn.individual.treemanagement.client.control.TipsDialog;
import cn.individual.treemanagement.client.pojo.RoleEnum;
import cn.individual.treemanagement.client.pojo.TreeStatusEnum;
import cn.individual.treemanagement.client.pojo.vo.LoginResult;
import cn.individual.treemanagement.client.pojo.vo.OutstandingTreeVO;
import cn.individual.treemanagement.client.pojo.vo.TreeVO;
import cn.individual.treemanagement.client.util.LocalCacheUtil;
import javafx.application.Platform;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.concurrent.Task;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.concurrent.ThreadPoolExecutor;

/**
 * @author li
 * @date create in 2025/1/22 13:58
 **/
public class OutstandingController {
    @FXML
    public DatePicker startDatePicker;

    @FXML
    public DatePicker endDatePicker;

    @FXML
    public TextField keywordText;

    @FXML
    public Button queryButton;

    @FXML
    public Button finalizedButton;

    @FXML
    public TableView<OutstandingTreeVO> outstandingTableView;

    @FXML
    public TableColumn<OutstandingTreeVO, String> genusColumn;

    @FXML
    public TableColumn<OutstandingTreeVO, String> speciesColumn;

    @FXML
    public TableColumn<OutstandingTreeVO, String> nameColumn;

    @FXML
    public TableColumn<OutstandingTreeVO, Double> bustSizeColumn;

    @FXML
    public TableColumn<OutstandingTreeVO, Double> heightColumn;

    @FXML
    public TableColumn<OutstandingTreeVO, String> developmentalStageColumn;

    @FXML
    public TableColumn<OutstandingTreeVO, Double> longitudeColumn;

    @FXML
    public TableColumn<OutstandingTreeVO, Double> latitudeColumn;

    @FXML
    public TableColumn<OutstandingTreeVO, LocalDateTime> createTimeColumn;

    private List<OutstandingTreeVO> outstandingTreeList;

    private ObjectProperty<LocalDate> startDate;

    private ObjectProperty<LocalDate> endDate;

    private SimpleStringProperty keyword;

    private TreeApi treeApi;

    private AdminApi adminApi;

    @FXML
    public void outstandingTreeList(ActionEvent actionEvent) {
        Platform.runLater(treeListTask());
    }

    @FXML
    public void finalizedOutstandingTree(ActionEvent actionEvent) {
        Platform.runLater(finalizedTreeTask());
    }

    @FXML
    public void initialize() {
        this.treeApi = new TreeApi();
        this.adminApi = new AdminApi();
        this.outstandingTreeList = treeApi.outstandingTreeList(null, null, null);
        LoginResult loginUser = (LoginResult) LocalCacheUtil.get(Constants.LOGIN_USER);
        if(!loginUser.getRoleId().equals(RoleEnum.Admin.getCode())) {
            finalizedButton.setManaged(false);
        }
        this.bindQueryEvent();
        this.setOutstandingTableView();
        this.setTableColumns();
    }

    private void bindQueryEvent() {
        startDate = new SimpleObjectProperty<>();
        endDate = new SimpleObjectProperty<>();
        keyword = new SimpleStringProperty();
        startDatePicker.valueProperty().bindBidirectional(startDate);
        endDatePicker.valueProperty().bindBidirectional(endDate);
        keywordText.textProperty().bindBidirectional(keyword);
    }

    private void setOutstandingTableView() {
        ObservableList<OutstandingTreeVO> observableList = FXCollections.observableList(outstandingTreeList);
        outstandingTableView.setItems(observableList);
    }

    private void setTableColumns() {
        genusColumn.setCellValueFactory(new PropertyValueFactory<>("genus"));
        speciesColumn.setCellValueFactory(new PropertyValueFactory<>("species"));
        nameColumn.setCellValueFactory(new PropertyValueFactory<>("commonName"));
        bustSizeColumn.setCellValueFactory(new PropertyValueFactory<>("bustSize"));
        heightColumn.setCellValueFactory(new PropertyValueFactory<>("height"));
        developmentalStageColumn.setCellValueFactory(new PropertyValueFactory<>("developmentalStage"));
        longitudeColumn.setCellValueFactory(new PropertyValueFactory<>("longitude"));
        latitudeColumn.setCellValueFactory(new PropertyValueFactory<>("latitude"));
        createTimeColumn.setCellValueFactory(new PropertyValueFactory<>("createTime"));
    }

    private Task<List<OutstandingTreeVO>> treeListTask() {
        Task<List<OutstandingTreeVO>> treeListTask = new Task<List<OutstandingTreeVO>>() {
            @Override
            protected List<OutstandingTreeVO> call() throws Exception {
                return treeApi.outstandingTreeList(startDate.getValue(), endDate.getValue(), keyword.getValue());
            }
        };
        treeListTask.setOnSucceeded(event -> {
            outstandingTableView.getItems().clear();
            outstandingTableView.getItems().addAll(treeListTask.getValue());
        });
        return treeListTask;
    }

    private Task<Void> finalizedTreeTask() {
        Task<Void> finalizedTreeTask = new Task<Void>() {
            @Override
            protected Void call() throws Exception {
                adminApi.finalizedTree();
                return null;
            }
        };
        finalizedTreeTask.setOnSucceeded(event -> {
            Platform.runLater(treeListTask());
            TipsDialog tipsDialog = new TipsDialog("Finalized tree success!");
            tipsDialog.show();
        });
        return finalizedTreeTask;
    }
}
