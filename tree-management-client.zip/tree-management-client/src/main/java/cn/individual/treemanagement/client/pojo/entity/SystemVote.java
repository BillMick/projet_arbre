package cn.individual.treemanagement.client.pojo.entity;

import lombok.Data;

import java.time.LocalDateTime;

/**
 * @author li
 * @date create in 2025/1/17 10:04
 **/
@Data
public class SystemVote {
    private Integer id;

    private Long userId;

    private Long voteId;

    private LocalDateTime createTime;

    private LocalDateTime updateTime;
}
