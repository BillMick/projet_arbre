package cn.individual.treemanagement.client.pojo.form;

import lombok.Data;

import java.io.Serializable;
import java.time.LocalDate;

/**
 * @author li
 * @date create in 2025/1/13 11:19
 **/
@Data
public class UserForm implements Serializable {
    private String username;
    /**
     * 密码
     */
    private String password;
    /**
     * 名字
     */
    private String firstName;
    /**
     * 姓
     */
    private String lastName;
    /**
     * 出生日期
     */
    private LocalDate birthday;
    /**
     * 地址
     */
    private String address;
}
