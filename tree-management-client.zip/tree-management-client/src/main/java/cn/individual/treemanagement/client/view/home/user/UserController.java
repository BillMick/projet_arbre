package cn.individual.treemanagement.client.view.home.user;

import cn.individual.treemanagement.client.api.AdminApi;
import cn.individual.treemanagement.client.api.UserApi;
import cn.individual.treemanagement.client.api.VoteApi;
import cn.individual.treemanagement.client.config.InitConfigurer;
import cn.individual.treemanagement.client.control.TipsDialog;
import cn.individual.treemanagement.client.pojo.RoleEnum;
import cn.individual.treemanagement.client.pojo.StatusEnum;
import cn.individual.treemanagement.client.pojo.vo.SystemUserVO;
import cn.individual.treemanagement.client.pojo.vo.SystemVoteVO;
import cn.individual.treemanagement.client.util.LocalStorage;
import javafx.application.Platform;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.concurrent.Task;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.HBox;
import javafx.util.Callback;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

/**
 * @author li
 * @date create in 2025/1/22 13:58
 **/
public class UserController {
    @FXML
    public DatePicker startDatePicker;

    @FXML
    public DatePicker endDatePicker;

    @FXML
    public TextField keywordText;

    @FXML
    public ComboBox<String> statusSelector;

    @FXML
    public Button queryButton;

    @FXML
    public TableView<SystemUserVO> userTableView;

    @FXML
    public TableColumn<SystemUserVO, String> usernameColumn;

    @FXML
    public TableColumn<SystemUserVO, String> firstNameColumn;

    @FXML
    public TableColumn<SystemUserVO, String> lastNameColumn;

    @FXML
    public TableColumn<SystemUserVO, LocalDate> birthdayColumn;

    @FXML
    public TableColumn<SystemUserVO, String> addressColumn;

    @FXML
    public TableColumn<SystemUserVO, String> roleColumn;

    @FXML
    public TableColumn<SystemUserVO, String> statusColumn;

    @FXML
    public TableColumn<SystemUserVO, LocalDate> registrationTimeColumn;

    @FXML
    public TableColumn<SystemUserVO, LocalDate> updateTimeColumn;

    @FXML
    public TableColumn<SystemUserVO, String> operationColumn;

    private List<SystemUserVO> userList;

    private List<SystemVoteVO> voteList;

    private AdminApi adminApi;

    private UserApi userApi;

    private VoteApi voteApi;

    private ObjectProperty<LocalDate> startDate;

    private ObjectProperty<LocalDate> endDate;

    private SimpleStringProperty keyword;

    private Integer status;

    @FXML
    public void userList(ActionEvent actionEvent) {
        Platform.runLater(userListTask());
    }

    @FXML
    public void initialize() {
        userApi = new UserApi();
        adminApi = new AdminApi();
        voteApi = new VoteApi();
        userList = userApi.getUserList(null, null, null, null);
        voteList = voteApi.getMyselfVoteList();
        this.bindQueryEvent();
        this.setUserTableView();
        this.setTableColumns();
    }

    private void bindQueryEvent() {
        startDate = new SimpleObjectProperty<>();
        endDate = new SimpleObjectProperty<>();
        keyword = new SimpleStringProperty();
        startDatePicker.valueProperty().bindBidirectional(startDate);
        endDatePicker.valueProperty().bindBidirectional(endDate);
        keywordText.textProperty().bindBidirectional(keyword);
        List<String> statusList = Arrays.stream(StatusEnum.values()).map(Enum::name).collect(Collectors.toList());
        statusSelector.getItems().addAll(statusList);
        statusSelector.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) -> {
            StatusEnum statusEnum = StatusEnum.valueOf(newValue);
            this.status = statusEnum.getStatus();
        });
    }

    private void setUserTableView() {
        ObservableList<SystemUserVO> observableList = FXCollections.observableList(userList);
        userTableView.setItems(observableList);
    }

    private void setTableColumns() {
        usernameColumn.setCellValueFactory(new PropertyValueFactory<>("username"));
        firstNameColumn.setCellValueFactory(new PropertyValueFactory<>("firstName"));
        lastNameColumn.setCellValueFactory(new PropertyValueFactory<>("lastName"));
        birthdayColumn.setCellValueFactory(new PropertyValueFactory<>("birthday"));
        addressColumn.setCellValueFactory(new PropertyValueFactory<>("address"));
        roleColumn.setCellValueFactory(cellData->{
            Integer roleId = cellData.getValue().getRoleId();
            RoleEnum role = RoleEnum.getRoleByCode(roleId);
            return new SimpleStringProperty(role.getName());
        });
        statusColumn.setCellValueFactory(cellData->{
            Integer status = cellData.getValue().getStatus();
            StatusEnum statusEnum = StatusEnum.getStatusEnum(status);
            return new SimpleStringProperty(statusEnum.getName());
        });
        registrationTimeColumn.setCellValueFactory(new PropertyValueFactory<>("registrationTime"));
        updateTimeColumn.setCellValueFactory(new PropertyValueFactory<>("updateTime"));
        operationColumn.setCellValueFactory(new PropertyValueFactory<>("operation"));
        this.operationColumn();
    }

    private void operationColumn() {
        operationColumn.setCellFactory(new Callback<TableColumn<SystemUserVO, String>, TableCell<SystemUserVO, String>>() {
            @Override
            public TableCell<SystemUserVO, String> call(TableColumn<SystemUserVO, String> param) {
                return new TableCell<SystemUserVO, String>() {
                    @Override
                    public void updateItem(String item, boolean empty) {
                        super.updateItem(item, empty);
                        if(empty) {
                            setGraphic(null);
                        } else {
                            HBox hBox = new HBox();
                            hBox.setSpacing(5.0);
                            setGraphic(hBox);
                            SystemUserVO systemUserVO = getTableView().getItems().get(getIndex());
                            Integer roleId = systemUserVO.getRoleId();
                            Integer status = systemUserVO.getStatus();
                            Long userId = systemUserVO.getUserId();
                            if(LocalStorage.role.equals(RoleEnum.Admin)) {
                                hBox.getChildren().add(editButton(userId));
                                // todo 封禁解禁逻辑需要考虑Guest角色
                                if(status.equals(StatusEnum.Normal.getStatus())) {
                                    hBox.getChildren().add(disableButton(userId));
                                } else if(status.equals(StatusEnum.Disable.getStatus())) {
                                    hBox.getChildren().add(enableButton(userId));
                                }
                            }
                            if(!RoleEnum.getRoleByCode(roleId).equals(RoleEnum.Guest)) {
                                hBox.getChildren().add(voteButton(userId));
                            }
                        }
                    }
                };
            }
        });
    }

    Button enableButton(Long userId) {
        Button enableButton = new Button("Enable");
        enableButton.setOnAction(event -> {
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Enable System User");
            alert.setHeaderText(null);
            alert.setContentText("Are you sure you want to enable system user " + userId + "?");
            ButtonType result = alert.showAndWait().orElse(ButtonType.CANCEL);
            if(result == ButtonType.OK) {
                Platform.runLater(enableTask(userId));
            }
        });
        return enableButton;
    }

    Button disableButton(Long userId) {
        Button enableButton = new Button("Disable");
        enableButton.setOnAction(event -> {
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Disable System User");
            alert.setHeaderText(null);
            alert.setContentText("Are you sure you want to disable system user " + userId + "?");
            ButtonType result = alert.showAndWait().orElse(ButtonType.CANCEL);
            if(result == ButtonType.OK) {
                Platform.runLater(disableTask(userId));
            }
        });
        return enableButton;
    }

    Button editButton(Long userId) {
        Button editButton = new Button("Edit");
        editButton.setOnAction(event -> {
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Reset System User Password");
            alert.setHeaderText(null);
            alert.setContentText("Are you sure you want to disable system user " + userId + "?");
            ButtonType result = alert.showAndWait().orElse(ButtonType.CANCEL);
            if(result == ButtonType.OK) {
                Platform.runLater(editTask(userId));
            }
        });
        return editButton;
    }

    Button voteButton(Long userId) {
        boolean find = voteList.stream().anyMatch(systemVoteVO -> systemVoteVO.getVoteId().equals(userId));
        if(find) {
            Button voteButton = new Button("Already Vote");
            voteButton.disabledProperty();
            return voteButton;
        }
        Button voteButton = new Button("Vote");
        voteButton.setOnAction(event -> {
            TipsDialog tipsDialog = new TipsDialog("Vote System User", "Are you sure you want to vote system user " + userId + "?");
            ButtonType result = tipsDialog.showAndWait();
            if(result == ButtonType.OK) {
                voteApi.voteUser(userId);
            }
        });
        return voteButton;
    }

    private Task<List<SystemUserVO>> userListTask() {
        Task<List<SystemUserVO>> userListTask = new Task<List<SystemUserVO>>() {
            @Override
            protected List<SystemUserVO> call() throws Exception {
                return userApi.getUserList(startDate.getValue(), endDate.getValue(), status, keyword.getValue());
            }
        };
        userListTask.setOnSucceeded(event -> {
            userTableView.getItems().clear();
            userTableView.getItems().addAll(userListTask.getValue());
        });
        return userListTask;
    }

    Task<Void> enableTask(Long userId) {
        Task<Void> enableTask = new Task<Void>() {
            @Override
            protected Void call() throws Exception {
                adminApi.enableUser(userId);
                return null;
            }
        };
        enableTask.setOnSucceeded(event -> {
            TipsDialog tipsDialog = new TipsDialog("System User Enabled Successfully");
            tipsDialog.show();
            Platform.runLater(userListTask());
        });
        return enableTask;
    }

    Task<Void> disableTask(Long userId) {
        Task<Void> disableTask = new Task<Void>() {
            @Override
            protected Void call() throws Exception {
                adminApi.disableUser(userId);
                return null;
            }
        };
        disableTask.setOnSucceeded(event -> {
            TipsDialog tipsDialog = new TipsDialog("System User Disable Successfully");
            tipsDialog.show();
            Platform.runLater(userListTask());
        });
        return disableTask;
    }

    Task<Void> editTask(Long userId) {
        Task<Void> editTask = new Task<Void>() {
            @Override
            protected Void call() throws Exception {
                adminApi.resetPassword(userId);
                return null;
            }
        };
        editTask.setOnSucceeded(event -> {
            TipsDialog tipsDialog = new TipsDialog("System User Password Reset Successfully");
            tipsDialog.show();
        });
        return editTask;
    }

}
