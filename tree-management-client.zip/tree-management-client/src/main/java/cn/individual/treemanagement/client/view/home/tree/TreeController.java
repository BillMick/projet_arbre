package cn.individual.treemanagement.client.view.home.tree;

import cn.individual.treemanagement.client.api.TreeApi;
import cn.individual.treemanagement.client.common.Constants;
import cn.individual.treemanagement.client.config.InitConfigurer;
import cn.individual.treemanagement.client.pojo.RoleEnum;
import cn.individual.treemanagement.client.pojo.TreeStatusEnum;
import cn.individual.treemanagement.client.pojo.vo.LoginResult;
import cn.individual.treemanagement.client.pojo.vo.TreeVO;
import cn.individual.treemanagement.client.util.LocalCacheUtil;
import cn.individual.treemanagement.client.util.LocalStorage;
import javafx.application.Platform;
import javafx.beans.property.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.concurrent.Task;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;
import javafx.util.Callback;

import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.stream.Collectors;

/**
 * @author li
 * @date create in 2025/1/22 13:58
 **/
public class TreeController {
    private TreeApi treeApi;

    @FXML
    public DatePicker startDatePicker;

    @FXML
    public DatePicker endDatePicker;

    @FXML
    public TextField keywordText;

    @FXML
    public ComboBox<String> statusSelector;

    @FXML
    public Button queryButton;

    @FXML
    public Button addTreeButton;

    @FXML
    public TableView<TreeVO> treeTableView;

    @FXML
    public TableColumn<TreeVO, String> genusColumn;

    @FXML
    public TableColumn<TreeVO, String> speciesColumn;

    @FXML
    public TableColumn<TreeVO, String> nameColumn;

    @FXML
    public TableColumn<TreeVO, Double> bustSizeColumn;

    @FXML
    public TableColumn<TreeVO, Double> heightColumn;

    @FXML
    public TableColumn<TreeVO, String> developmentalStageColumn;

    @FXML
    public TableColumn<TreeVO, Double> longitudeColumn;

    @FXML
    public TableColumn<TreeVO, Double> latitudeColumn;

    @FXML
    public TableColumn<TreeVO, String> statusColumn;

    @FXML
    public TableColumn<TreeVO, LocalDateTime> createTimeColumn;

    @FXML
    public TableColumn<TreeVO, LocalDateTime> updateTimeColumn;

    @FXML
    public TableColumn<TreeVO, String> operationColumn;

    private ObjectProperty<LocalDate> startDate;

    private ObjectProperty<LocalDate> endDate;

    private SimpleStringProperty keyword;

    private Integer status;

    private List<TreeVO> treeList;

    @FXML
    public void initialize() {
        this.treeApi = new TreeApi();
        treeList = treeApi.treeList(null, null, null, null);
        this.bindQueryEvent();
        this.setTreeTableView();
        this.setTableColumns();
        LoginResult loginUser = (LoginResult) LocalCacheUtil.get(Constants.LOGIN_USER);
        if(loginUser.getRoleId().equals(RoleEnum.Guest.getCode())) {
            addTreeButton.setDisable(true);
        }
    }

    @FXML
    public void treeList(ActionEvent actionEvent) {
        Platform.runLater(treeListTask());
    }

    @FXML
    public void addTree(ActionEvent actionEvent) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getClassLoader().getResource("view/home/tree/AddTreeController.fxml"));
        AddTreeController addTreeController = new AddTreeController();
        loader.setController(addTreeController);
        Parent root = loader.load();        Stage addTreeStage = new Stage();
        addTreeStage.setTitle("Add Tree");
        Scene addTreeScene = new Scene(root, 500, 600);
        addTreeStage.setScene(addTreeScene);
        addTreeStage.show();
    }

    private void bindQueryEvent() {
        startDate = new SimpleObjectProperty<>();
        endDate = new SimpleObjectProperty<>();
        keyword = new SimpleStringProperty();
        startDatePicker.valueProperty().bindBidirectional(startDate);
        endDatePicker.valueProperty().bindBidirectional(endDate);
        keywordText.textProperty().bindBidirectional(keyword);
        List<String> selectors = Arrays.stream(TreeStatusEnum.values()).map(TreeStatusEnum::name).collect(Collectors.toList());
        statusSelector.getItems().setAll(selectors);
        statusSelector.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) -> {
            TreeStatusEnum statusEnum = TreeStatusEnum.valueOf(newValue);
            this.status = statusEnum.getStatus();
        });
    }

    private void setTreeTableView() {
        ObservableList<TreeVO> observableList = FXCollections.observableList(treeList);
        treeTableView.setItems(observableList);
    }

    private void setTableColumns() {
        genusColumn.setCellValueFactory(new PropertyValueFactory<>("genus"));
        speciesColumn.setCellValueFactory(new PropertyValueFactory<>("species"));
        nameColumn.setCellValueFactory(new PropertyValueFactory<>("commonName"));
        bustSizeColumn.setCellValueFactory(new PropertyValueFactory<>("bustSize"));
        heightColumn.setCellValueFactory(new PropertyValueFactory<>("height"));
        developmentalStageColumn.setCellValueFactory(new PropertyValueFactory<>("developmentalStage"));
        longitudeColumn.setCellValueFactory(new PropertyValueFactory<>("longitude"));
        latitudeColumn.setCellValueFactory(new PropertyValueFactory<>("latitude"));
        statusColumn.setCellValueFactory(cellData->{
            Integer status = cellData.getValue().getStatus();
            TreeStatusEnum statusEnum = TreeStatusEnum.getTreeStatusEnum(status);
            return new SimpleStringProperty(statusEnum.getName());
        });
        createTimeColumn.setCellValueFactory(new PropertyValueFactory<>("createTime"));
        updateTimeColumn.setCellValueFactory(new PropertyValueFactory<>("updateTime"));
        this.operationColumn();
    }

    private void operationColumn() {
        operationColumn.setCellFactory(new Callback<TableColumn<TreeVO, String>, TableCell<TreeVO, String>>() {
            @Override
            public TableCell<TreeVO, String> call(TableColumn<TreeVO, String> param) {
                return new TableCell<TreeVO, String>() {
                    @Override
                    public void updateItem(String item, boolean empty) {
                        super.updateItem(item, empty);
                        if(empty) {
                            setGraphic(null);
                        } else {
                            HBox hBox = new HBox();
                            hBox.setSpacing(5);
                            setGraphic(hBox);
                            TreeVO tree = getTableView().getItems().get(getIndex());
                            Long treeId = tree.getTreeId();
                            if(!LocalStorage.role.equals(RoleEnum.Guest)) {
                                hBox.getChildren().addAll(updateTreeButton(tree), maintenanceTreeButton(treeId), nominateTreeButton(treeId));
                            }
                        }
                    }
                };
            }
        });
    }

    private Button updateTreeButton(TreeVO tree) {
        Button updateTreeButton = new Button("Edit Tree");
        updateTreeButton.setOnAction(event -> {
            try {
                FXMLLoader loader = new FXMLLoader(getClass().getClassLoader().getResource("view/home/tree/AddTreeController.fxml"));
                AddTreeController addTreeController = new AddTreeController(tree);
                loader.setController(addTreeController);
                Parent root = loader.load();
                Stage addTreeStage = new Stage();
                addTreeStage.setTitle("Update Tree");
                Scene addTreeScene = new Scene(root, 500, 600);
                addTreeStage.setScene(addTreeScene);
                addTreeStage.show();
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        });
        return updateTreeButton;
    }

    private Button maintenanceTreeButton(Long treeId) {
        Button maintenanceTreeButton = new Button("Maintenance Tree");
        maintenanceTreeButton.setOnAction(event -> {
            Platform.runLater(maintenanceTreeTask(treeId));
        });
        return maintenanceTreeButton;
    }

    private Button nominateTreeButton(Long treeId) {
        Button nominateTreeButton = new Button("Nominate Tree");
        nominateTreeButton.setOnAction(event -> {
            Platform.runLater(nominateTreeTask(treeId));
        });
        return nominateTreeButton;
    }

    private Task<Void> maintenanceTreeTask(Long treeId) {
        Task<Void> maintenanceTreeTask = new Task<Void>() {
            @Override
            protected Void call() throws Exception {
                treeApi.submitMaintenanceTree(treeId);
                return null;
            }
        };
        maintenanceTreeTask.setOnSucceeded(event -> {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Maintenance Tree");
            alert.setHeaderText(null);
            alert.setContentText("Submit Maintenance Tree Successfully");
            alert.showAndWait();
        });
        return maintenanceTreeTask;
    }

    private Task<Void> nominateTreeTask(Long treeId) {
        Task<Void> nominateTreeTask = new Task<Void>() {
            @Override
            protected Void call() throws Exception {
                treeApi.nominateTree(treeId);
                return null;
            }
        };
        nominateTreeTask.setOnSucceeded(event -> {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Nominate Tree");
            alert.setHeaderText(null);
            alert.setContentText("Submit Nominate Tree Successfully");
            alert.showAndWait();
        });
        return nominateTreeTask;
    }

    private Task<List<TreeVO>> treeListTask() {
        Task<List<TreeVO>> treeListTask = new Task<List<TreeVO>>() {
            @Override
            protected List<TreeVO> call() throws Exception {
                return treeApi.treeList(startDate.getValue(), endDate.getValue(), status, keyword.getValue());
            }
        };
        treeListTask.setOnSucceeded(event -> {
            treeTableView.getItems().clear();
            treeTableView.getItems().addAll(treeListTask.getValue());
        });
        treeListTask.setOnFailed(event -> {

        });
        return treeListTask;
    }

}
