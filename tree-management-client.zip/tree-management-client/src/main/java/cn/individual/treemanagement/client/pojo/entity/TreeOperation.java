package cn.individual.treemanagement.client.pojo.entity;

import lombok.Data;

import java.io.Serializable;
import java.time.LocalDateTime;

@Data
public class TreeOperation implements Serializable {
	/**
	 * 主键id
	 */
	private Long operationId;

	private Long userId;
	/**
	 * 树木id
	 */
	private Long treeId;
	/**
	 * 操作:种植、砍伐、提名
	 */
	private Integer operate;
	/**
	 * 创建时间
	 */
	private LocalDateTime createTime;
	/**
	 * 更新时间
	 */
	private LocalDateTime updateTime;
}
