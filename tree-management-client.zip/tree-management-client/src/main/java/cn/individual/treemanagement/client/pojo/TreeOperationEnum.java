package cn.individual.treemanagement.client.pojo;

import lombok.Getter;

public enum TreeOperationEnum {

    Planting(0, "种植"),
    Update(1, "更新"),
    Maintenance(2, "维护"),
    Nominate(3, "提名");

    @Getter
    private Integer code;

    @Getter
    private String name;

    TreeOperationEnum(Integer code, String name) {
        this.code = code;
        this.name = name;
    }

    public static TreeOperationEnum getEnum(Integer code) {
        TreeOperationEnum[] values = values();
        for (TreeOperationEnum value : values) {
            if (value.code.equals(code)) {
                return value;
            }
        }
        return null;
    }
}
