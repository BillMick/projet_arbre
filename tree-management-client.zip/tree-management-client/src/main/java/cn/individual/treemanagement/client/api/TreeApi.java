package cn.individual.treemanagement.client.api;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import cn.individual.treemanagement.client.config.InitConfigurer;
import cn.individual.treemanagement.client.pojo.form.TreeForm;
import cn.individual.treemanagement.client.pojo.vo.OutstandingTreeVO;
import cn.individual.treemanagement.client.pojo.vo.TreeVO;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static cn.individual.treemanagement.client.common.UrlPath.*;

/**
 * @author li
 * @date create in 2025/1/18 12:01
 **/
public class TreeApi {

    private ObjectMapper objectMapper;

    public TreeApi() {
        objectMapper = InitConfigurer.objectMapper;
    }

    public List<TreeVO> treeList(LocalDate startDate, LocalDate endDate, Integer status, String keyword) {
        Map<String, Object> params = new HashMap<>();
        params.put("startDate", startDate);
        params.put("endDate", endDate);
        params.put("keyword", keyword);
        params.put("status", status);
        JsonNode data = Request.getRequest(domain + treeListApi, params);
        return objectMapper.convertValue(data, objectMapper.getTypeFactory().constructCollectionType(List.class, TreeVO.class));
    }

    public void updateTree(Long treeId, TreeForm form) {
        JsonNode formData = objectMapper.convertValue(form, JsonNode.class);
        Request.postRequest(domain + updateTreeApi + "?treeId=" + treeId, formData);
    }

    public void submitMaintenanceTree(Long treeId) {
        MultiValueMap<String, Object> formData = new LinkedMultiValueMap<>();
        formData.add("treeId", treeId);
        Request.postRequest(domain + submitMaintenanceTreeApi, formData);
    }

    public void nominateTree(Long treeId) {
        MultiValueMap<String, Object> formData = new LinkedMultiValueMap<>();
        formData.add("treeId", treeId);
        Request.postRequest(domain + nominateTreeApi, formData);
    }

    public void registeredTree(TreeForm form) {
        JsonNode formData = objectMapper.convertValue(form, JsonNode.class);
        Request.postRequest(domain + registeredTreeApi, formData);
    }

    public List<OutstandingTreeVO> outstandingTreeList(LocalDate startDate, LocalDate endDate, String keyword) {
        Map<String, Object> params = new HashMap<>();
        params.put("startDate", startDate);
        params.put("endDate", endDate);
        params.put("keyword", keyword);
        JsonNode data = Request.getRequest(domain + outstandingTreeApi, params);
        return objectMapper.convertValue(data, objectMapper.getTypeFactory().constructCollectionType(List.class, OutstandingTreeVO.class));
    }
}
