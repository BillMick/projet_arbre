package cn.individual.treemanagement.client.view.login;

import cn.individual.treemanagement.client.api.UserApi;
import cn.individual.treemanagement.client.control.TipsDialog;
import cn.individual.treemanagement.client.pojo.form.UserForm;
import cn.individual.treemanagement.client.util.AESUtil;
import javafx.application.Platform;
import javafx.concurrent.Task;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

/**
 * @author li
 * @date create in 2025/1/23 16:24
 **/
public class RegisterController {

    @FXML
    public TextField usernameText;

    @FXML
    public TextField passwordText;

    @FXML
    public TextField firstNameText;

    @FXML
    public TextField lastNameText;

    @FXML
    public DatePicker birthdayPicker;

    @FXML
    public TextField addressText;

    @FXML
    public Button registerButton;

    @FXML
    public Button cancelButton;

    private UserApi userApi;

    @FXML
    public void registerUser(ActionEvent actionEvent) {
        Platform.runLater(registerUserTask());
    }

    @FXML
    public void cancel(ActionEvent actionEvent) {
        Stage stage = (Stage) cancelButton.getScene().getWindow();
        stage.close();
    }

    @FXML
    public void initialize() {
        this.userApi = new UserApi();
    }

    private Task<Void> registerUserTask() {
        Task<Void> registerUserTask = new Task<Void>() {
            @Override
            protected Void call() throws Exception {
                UserForm userForm = new UserForm();
                userForm.setUsername(usernameText.getText());
                userForm.setPassword(AESUtil.encrypt(passwordText.getText()));
                userForm.setFirstName(firstNameText.getText());
                userForm.setLastName(lastNameText.getText());
                userForm.setBirthday(birthdayPicker.getValue());
                userForm.setAddress(addressText.getText());
                userApi.registerUser(userForm);
                return null;
            }
        };
        registerUserTask.setOnSucceeded(event -> {
            TipsDialog tipsDialog = new TipsDialog("Register Success");
            tipsDialog.show();
            cancelButton.fire();
        });
        return registerUserTask;
    }
}
