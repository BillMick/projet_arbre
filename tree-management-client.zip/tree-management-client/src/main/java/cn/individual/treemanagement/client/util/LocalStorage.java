package cn.individual.treemanagement.client.util;

import cn.individual.treemanagement.client.pojo.RoleEnum;
import cn.individual.treemanagement.client.pojo.vo.LoginResult;

/**
 * @author li
 * @date create in 2025/1/18-23:11
 **/
public class LocalStorage {

    public static LoginResult loginResult = new LoginResult();

    public static String accessToken = "";

    public static RoleEnum role;
}
