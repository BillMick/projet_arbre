package cn.individual.treemanagement.client.view.home.dues;

import cn.individual.treemanagement.client.api.AdminApi;
import cn.individual.treemanagement.client.api.DuesApi;
import cn.individual.treemanagement.client.common.Constants;
import cn.individual.treemanagement.client.config.InitConfigurer;
import cn.individual.treemanagement.client.control.TipsDialog;
import cn.individual.treemanagement.client.pojo.PaidEnum;
import cn.individual.treemanagement.client.pojo.RoleEnum;
import cn.individual.treemanagement.client.pojo.vo.LoginResult;
import cn.individual.treemanagement.client.pojo.vo.SystemUserDuesVO;
import cn.individual.treemanagement.client.util.LocalCacheUtil;
import javafx.application.Platform;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.concurrent.Task;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.util.converter.DoubleStringConverter;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

/**
 * @author li
 * @date create in 2025/1/22 13:58
 **/
public class DuesController {
    @FXML
    public DatePicker startDatePicker;

    @FXML
    public DatePicker endDatePicker;

    @FXML
    public ComboBox<String> paidSelector;

    @FXML
    public Button queryButton;

    @FXML
    public TextField duesText;

    @FXML
    public Button setDuesButton;

    @FXML
    public TableView<SystemUserDuesVO> donateTableView;

    @FXML
    public TableColumn<SystemUserDuesVO, String> usernameColumn;

    @FXML
    public TableColumn<SystemUserDuesVO, Double> duesColumn;

    @FXML
    public TableColumn<SystemUserDuesVO, String> paidColumn;

    @FXML
    public TableColumn<SystemUserDuesVO, Integer> yearColumn;

    @FXML
    public TableColumn<SystemUserDuesVO, LocalDate> createTimeColumn;

    @FXML
    public TableColumn<SystemUserDuesVO, LocalDate> updateTimeColumn;

    private List<SystemUserDuesVO> userDuesList;

    private ObjectProperty<LocalDate> startDate;

    private ObjectProperty<LocalDate> endDate;

    private Integer paid;

    private DuesApi duesApi;

    private AdminApi adminApi;


    @FXML
    public void payDuesList(ActionEvent actionEvent) {
        Platform.runLater(userDuesListTask());
    }

    @FXML
    public void setDues(ActionEvent actionEvent) {
        Platform.runLater(setDuesTask());
    }

    @FXML
    public void initialize() {
        this.duesApi = new DuesApi();
        this.adminApi = new AdminApi();
        userDuesList = duesApi.getUserDuesList(null, null, null);
        this.bindQueryEvent();
        this.setDonateTableView();
        this.setTableColumns();
        LoginResult loginUser = (LoginResult) LocalCacheUtil.get(Constants.LOGIN_USER);
        this.duesText.setTextFormatter(Constants.matchDoubleFormatter());
        if(!loginUser.getRoleId().equals(RoleEnum.Admin.getCode())) {
            setDuesButton.setManaged(false);
            duesText.setManaged(false);
        }
    }

    private void bindQueryEvent() {
        startDate = new SimpleObjectProperty<>();
        endDate = new SimpleObjectProperty<>();
        startDatePicker.valueProperty().bindBidirectional(startDate);
        endDatePicker.valueProperty().bindBidirectional(endDate);
        List<String> paidNames = Arrays.stream(PaidEnum.values()).map(Enum::name).collect(Collectors.toList());
        paidSelector.getItems().addAll(paidNames);
        paidSelector.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) -> {
            PaidEnum paidEnum = PaidEnum.valueOf(newValue);
            this.paid = paidEnum.getCode();
        });
    }

    private void setDonateTableView() {
        ObservableList<SystemUserDuesVO> observableList = FXCollections.observableList(userDuesList);
        donateTableView.setItems(observableList);
    }

    private void setTableColumns() {
        usernameColumn.setCellValueFactory(new PropertyValueFactory<>("username"));
        duesColumn.setCellValueFactory(new PropertyValueFactory<>("dues"));
        paidColumn.setCellValueFactory(cellData->{
            Integer paid = cellData.getValue().getPaid();
            PaidEnum paidEnum = PaidEnum.getEnum(paid);
            return new SimpleStringProperty(paidEnum.getName());
        });
        yearColumn.setCellValueFactory(new PropertyValueFactory<>("year"));
        createTimeColumn.setCellValueFactory(new PropertyValueFactory<>("createTime"));
        updateTimeColumn.setCellValueFactory(new PropertyValueFactory<>("updateTime"));
    }

    private Task<List<SystemUserDuesVO>> userDuesListTask() {
        Task<List<SystemUserDuesVO>> userDuesListTask = new Task<List<SystemUserDuesVO>>() {
            @Override
            protected List<SystemUserDuesVO> call() throws Exception {
                return duesApi.getUserDuesList(startDate.get(), endDate.get(), paid);
            }
        };

        userDuesListTask.setOnSucceeded(event -> {
            donateTableView.getItems().clear();
            donateTableView.getItems().addAll(userDuesListTask.getValue());
        });
        return userDuesListTask;
    }

    private Task<Void> setDuesTask() {
        Task<Void> setDuesTask = new Task<Void>() {
            @Override
            protected Void call() throws Exception {
                adminApi.setYearDues(Double.parseDouble(duesText.getText()));
                return null;
            }
        };
        setDuesTask.setOnSucceeded(event -> {
            TipsDialog tipsDialog = new TipsDialog("Set dues Success");
            tipsDialog.show();
        });
        return setDuesTask;
    }
}
