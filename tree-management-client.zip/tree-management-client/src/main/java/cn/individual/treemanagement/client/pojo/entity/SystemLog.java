package cn.individual.treemanagement.client.pojo.entity;

import lombok.Data;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * @author li
 * @date create in 2025/1/22-22:53
 **/
@Data
public class SystemLog implements Serializable {
    private Integer id;

    private String host;

    private String url;

    private Integer responseStatus;

    private String token;

    private LocalDateTime createTime;
}
