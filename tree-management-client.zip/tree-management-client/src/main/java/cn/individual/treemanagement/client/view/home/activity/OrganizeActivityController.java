package cn.individual.treemanagement.client.view.home.activity;

import cn.individual.treemanagement.client.api.ActivityApi;
import cn.individual.treemanagement.client.api.TreeApi;
import cn.individual.treemanagement.client.common.Constants;
import cn.individual.treemanagement.client.config.InitConfigurer;
import cn.individual.treemanagement.client.control.TipsDialog;
import cn.individual.treemanagement.client.pojo.form.ActivityForm;
import cn.individual.treemanagement.client.pojo.vo.OutstandingTreeVO;
import javafx.application.Platform;
import javafx.concurrent.Task;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.util.converter.DoubleStringConverter;
import javafx.util.converter.IntegerStringConverter;

import java.util.List;
import java.util.stream.Collectors;

/**
 * @author li
 * @date create in 2025/1/23 17:03
 **/
public class OrganizeActivityController {
    @FXML
    public ComboBox<Long> treeSelector;

    @FXML
    public TextField topicText;

    @FXML
    public TextField budgetText;

    @FXML
    public TextField numberText;

    @FXML
    public DatePicker activityDatePicker;

    @FXML
    public Button submitButton;

    @FXML
    public Button cancelButton;

    private TreeApi treeApi;

    private ActivityApi activityApi;

    @FXML
    public void submitActivity(ActionEvent actionEvent) {
        Platform.runLater(submitActivityTask());
    }

    @FXML
    public void cancel(ActionEvent actionEvent) {
        cancelButton.getScene().getWindow().hide();
    }

    @FXML
    public void initialize() {
        this.treeApi = new TreeApi();
        this.activityApi = new ActivityApi();
        Platform.runLater(outstandingTreeListTask());
        this.budgetText.setTextFormatter(Constants.matchDoubleFormatter());
        this.numberText.setTextFormatter(Constants.matchNumberFormatter());
    }

    private Task<List<OutstandingTreeVO>> outstandingTreeListTask() {
        Task<List<OutstandingTreeVO>> outstandingTreeListTask = new Task<List<OutstandingTreeVO>>() {
            @Override
            protected List<OutstandingTreeVO> call() throws Exception {
                return treeApi.outstandingTreeList(null, null, null);
            }
        };
        outstandingTreeListTask.setOnSucceeded(event -> {
            List<Long> treeIds = outstandingTreeListTask.getValue().stream()
                    .map(OutstandingTreeVO::getTreeId)
                    .collect(Collectors.toList());
            this.treeSelector.getItems().addAll(treeIds);
        });
        return outstandingTreeListTask;
    }

    private Task<Void> submitActivityTask() {
        Task<Void> submitActivityTask = new Task<Void>() {
            @Override
            protected Void call() throws Exception {
                ActivityForm activityForm = new ActivityForm();
                activityForm.setTreeId(treeSelector.getSelectionModel().getSelectedItem());
                activityForm.setTopic(topicText.getText());
                activityForm.setBudget(Double.parseDouble(budgetText.getText()));
                activityForm.setNumber(Integer.parseInt(numberText.getText()));
                activityForm.setActivityDate(activityDatePicker.getValue());
                activityApi.organizeActivity(activityForm);
                return null;
            }
        };
        submitActivityTask.setOnSucceeded(event -> {
            TipsDialog tipsDialog = new TipsDialog("Organize Activity Success");
            tipsDialog.show();
        });
        return submitActivityTask;
    }
}
