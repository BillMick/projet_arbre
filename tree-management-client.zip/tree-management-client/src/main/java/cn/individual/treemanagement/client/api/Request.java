package cn.individual.treemanagement.client.api;

import cn.individual.treemanagement.client.control.ErrorDialog;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import javafx.scene.control.Alert;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.*;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import java.net.URLEncoder;
import java.util.Map;

import static cn.individual.treemanagement.client.util.LocalStorage.accessToken;

/**
 * @author li
 * @date create in 2025/1/17 21:13
 **/
@Slf4j
public class Request {

    private static final RestTemplate restTemplate = new RestTemplate();

    private static final ObjectMapper objectMapper = new ObjectMapper();

    public static JsonNode getRequest(String url, Map<String, Object> paramMap) throws RestClientException {
        try {
            url += "?";
            for (Map.Entry<String, Object> param : paramMap.entrySet()) {
                String key = param.getKey();
                Object value = param.getValue();
                if(value != null) {
                    url += "&" + key + "=" + URLEncoder.encode(value.toString(), "UTF-8");
                }
            }
            HttpHeaders headers = new HttpHeaders();
            headers.set("Authorization", accessToken);
            HttpEntity<String> request = new HttpEntity<>(headers);
            ResponseEntity<String> response = restTemplate.exchange(url,HttpMethod.GET, request, String.class);
            return handleResponse(response);
        } catch (Exception e) {
            // 记录日志
            showErrorDialog(e.getMessage());
            throw new RuntimeException("Error during GET request: " + e.getMessage(), e);
        }
    }

    public static JsonNode postRequest(String url, MultiValueMap<String, Object> form) {
        try {
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
            headers.set("Authorization", accessToken);
            HttpEntity<MultiValueMap<String, Object>> request = new HttpEntity<>(form, headers);
            ResponseEntity<String> response = restTemplate.postForEntity(url, request, String.class);
            return handleResponse(response);
        } catch (Exception e) {
            showErrorDialog(e.getMessage());
            throw new RuntimeException("Error during POST request: " + e.getMessage(), e);
        }
    }

    public static JsonNode postRequest(String url, JsonNode params) {
        try {
            HttpHeaders headers = new HttpHeaders();
            headers.set("Authorization", accessToken);
            // 处理params为null的情况
            HttpEntity<JsonNode> request = new HttpEntity<>(params, headers);
            ResponseEntity<String> response = restTemplate.postForEntity(url, request, String.class);
            return handleResponse(response);
        } catch (Exception e) {
            // 记录日志
            log.error("Error during POST request: ", e);
            showErrorDialog(e.getMessage());
            throw new RuntimeException(e.getMessage(), e);
        }
    }

    private static JsonNode handleResponse(ResponseEntity<String> response) throws JsonProcessingException {
        if(response.getStatusCode() == HttpStatus.OK) {
            JsonNode result = objectMapper.readTree(response.getBody());
            if(result.get("code").asInt() == 200) {
                return result.get("data");
            } else {
                throw new RuntimeException(result.get("message").asText());
            }
        } else {
            throw new RuntimeException("Error during POST request: " + response.getBody());
        }
    }

    private static void showErrorDialog(String errorMessage) {
        ErrorDialog errorDialog = new ErrorDialog(errorMessage);
        errorDialog.show();
    }
}
