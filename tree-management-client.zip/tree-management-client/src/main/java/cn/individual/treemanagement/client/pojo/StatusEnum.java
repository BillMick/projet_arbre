package cn.individual.treemanagement.client.pojo;

import lombok.Getter;

import java.util.Objects;

public enum StatusEnum {

    Normal(0, "正常"),
    Renewal(1, "续费"),
    Disable(2, "封禁");

    @Getter
    private Integer status;

    @Getter
    private String name;

    StatusEnum(Integer status, String name) {
        this.status = status;
        this.name = name;
    }

    public static StatusEnum getStatusEnum(Integer status) {
        for (StatusEnum e : StatusEnum.values()) {
            if (Objects.equals(e.status, status)) {
                return e;
            }
        }
        return null;
    }
}
