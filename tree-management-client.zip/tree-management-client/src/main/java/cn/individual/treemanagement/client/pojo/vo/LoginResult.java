package cn.individual.treemanagement.client.pojo.vo;

import lombok.Data;

/**
 * @author li
 * @date create in 2024/6/1-23:12
 **/
@Data
public class LoginResult {

    private String accessToken;

    private Long expireTime;

    private Integer roleId;

    private Long userId;
}
