package cn.individual.treemanagement.client.pojo.vo;

import lombok.Data;

import java.io.Serializable;
import java.time.LocalDate;

/**
 * @author li
 * @date create in 2025/1/14 14:41
 **/
@Data
public class ActivityVO implements Serializable {
    private String username;
    /**
     * 活动主题
     */
    private String topic;
    /**
     * 活动经费
     */
    private Double budget;
    /**
     * 树木id
     */
    private Long treeId;

    private Integer number;

    private LocalDate activityDate;
}
