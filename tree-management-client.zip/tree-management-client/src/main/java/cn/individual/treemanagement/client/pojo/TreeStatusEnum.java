package cn.individual.treemanagement.client.pojo;

import lombok.Getter;

import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

public enum TreeStatusEnum {

    Normal(0, "正常"),
    Outstanding(1, "杰出"),
    Maintenance(2, "维护");

    @Getter
    private Integer status;

    @Getter
    private String name;

    TreeStatusEnum(Integer status, String name) {
        this.status = status;
        this.name = name;
    }

    public static TreeStatusEnum getTreeStatusEnum(Integer status) {
        for (TreeStatusEnum treeStatusEnum : TreeStatusEnum.values()) {
            if (Objects.equals(treeStatusEnum.getStatus(), status)) {
                return treeStatusEnum;
            }
        }
        return null;
    }

    public static List<String> treeStatusEnumNames() {
        return Arrays.stream(TreeStatusEnum.values()).map(TreeStatusEnum::name).collect(Collectors.toList());
    }
}
