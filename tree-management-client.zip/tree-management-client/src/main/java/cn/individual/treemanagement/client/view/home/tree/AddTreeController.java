package cn.individual.treemanagement.client.view.home.tree;

import cn.individual.treemanagement.client.api.TreeApi;
import cn.individual.treemanagement.client.common.Constants;
import cn.individual.treemanagement.client.control.TipsDialog;
import cn.individual.treemanagement.client.pojo.form.TreeForm;
import cn.individual.treemanagement.client.pojo.vo.TreeVO;
import javafx.application.Platform;
import javafx.concurrent.Task;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.control.TextFormatter;
import javafx.util.converter.DoubleStringConverter;

/**
 * @author li
 * @date create in 2025/1/23 17:31
 **/
public class AddTreeController {
    @FXML
    public TextField genusText;

    @FXML
    public TextField speciesText;

    @FXML
    public TextField commonNameText;

    @FXML
    public TextField bustSizeText;

    @FXML
    public TextField heightText;

    @FXML
    public TextField developmentalStageText;

    @FXML
    public TextField longitudeText;

    @FXML
    public TextField latitudeText;

    @FXML
    public Button addButton;

    @FXML
    public Button cancelButton;

    private TreeApi treeApi;

    private TreeVO treeVO;

    private boolean isAdd;

    public AddTreeController() {
        isAdd = true;
    }

    public AddTreeController(TreeVO treeVO) {
        this.treeVO = treeVO;
        isAdd = false;
    }

    @FXML
    public void addTree(ActionEvent actionEvent) {
        Platform.runLater(addTreeTask());
    }

    @FXML
    public void cancel(ActionEvent actionEvent) {
        cancelButton.getScene().getWindow().hide();
    }

    @FXML
    public void initialize() {
        this.treeApi = new TreeApi();
        this.bustSizeText.setTextFormatter(Constants.matchDoubleFormatter());
        this.heightText.setTextFormatter(Constants.matchDoubleFormatter());
        this.latitudeText.setTextFormatter(Constants.matchDoubleFormatter());
        this.longitudeText.setTextFormatter(Constants.matchDoubleFormatter());
        this.initDialog();
    }

    private void initDialog() {
        if(!isAdd) {
            genusText.setText(treeVO.getGenus());
            speciesText.setText(treeVO.getSpecies());
            commonNameText.setText(treeVO.getCommonName());
            bustSizeText.setText(treeVO.getBustSize().toString());
            heightText.setText(treeVO.getHeight().toString());
            developmentalStageText.setText(treeVO.getDevelopmentalStage());
            longitudeText.setText(treeVO.getLongitude().toString());
            latitudeText.setText(treeVO.getLatitude().toString());
        }
    }

    private Task<Void> addTreeTask() {
        Task<Void> addTreeTask = new Task<Void>() {
            @Override
            protected Void call() throws Exception {
                TreeForm treeForm = new TreeForm();
                treeForm.setGenus(genusText.getText());
                treeForm.setSpecies(speciesText.getText());
                treeForm.setCommonName(commonNameText.getText());
                treeForm.setBustSize(Double.parseDouble(bustSizeText.getText()));
                treeForm.setHeight(Double.parseDouble(heightText.getText()));
                treeForm.setDevelopmentalStage(developmentalStageText.getText());
                treeForm.setLongitude(Double.parseDouble(longitudeText.getText()));
                treeForm.setLatitude(Double.parseDouble(latitudeText.getText()));
                if(isAdd) {
                    treeApi.registeredTree(treeForm);
                } else {
                    treeApi.updateTree(treeVO.getTreeId(), treeForm);
                }
                return null;
            }
        };
        addTreeTask.setOnSucceeded(event -> {
            String message;
            if(isAdd) {
                message = "Add Tree Success";
            } else {
                message = "Update Tree Success";
            }
            TipsDialog tipsDialog = new TipsDialog(message);
            tipsDialog.show();
            cancelButton.fire();
        });
        return addTreeTask;
    }
}
