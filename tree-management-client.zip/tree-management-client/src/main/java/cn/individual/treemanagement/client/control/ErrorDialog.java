package cn.individual.treemanagement.client.control;

import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Dialog;
import javafx.scene.control.DialogPane;

/**
 * @author li
 * @date create in 2025/1/24 10:11
 **/
public class ErrorDialog {

    private Dialog<ButtonType> dialog;

    private DialogPane dialogPane;

    private Button okButton;

    private String title;

    private String message;

    public ErrorDialog(String message) {
        this.message = message;
        this.title = "Error";
    }

    public ErrorDialog(String title, String message) {
        this.title = title;
        this.message = message;
    }

    private void setOkButtonAction() {
        okButton.setOnAction((event) -> {
            dialog.close();
        });
    }

    private void showAndWait() {
        dialog.showAndWait()
                .filter(buttonType -> buttonType == ButtonType.OK)
                .ifPresent(buttonType -> {

                });
    }

    public void show() {
        dialog = new Dialog<>();
        dialog.setHeaderText("An error occurred");
        dialog.setContentText(message);
        dialogPane = dialog.getDialogPane();
        dialogPane.getButtonTypes().addAll(ButtonType.OK);
        okButton = (Button) dialog.getDialogPane().lookupButton(ButtonType.OK);
        this.setOkButtonAction();
        this.showAndWait();
    }

}
