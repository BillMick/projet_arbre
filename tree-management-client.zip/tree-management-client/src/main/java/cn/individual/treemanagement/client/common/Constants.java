package cn.individual.treemanagement.client.common;

import javafx.scene.control.TextFormatter;

import java.util.function.UnaryOperator;

/**
 * @author li
 * @date create in 2025/1/23 14:22
 **/
public class Constants {

    public static final String LOGIN_USER = "loginUser";

    public static TextFormatter<String> matchDoubleFormatter() {
        // 使用正则表达式限制只能输入正的浮点数
        UnaryOperator<TextFormatter.Change> filter = change -> {
            String newText = change.getControlNewText();
            if (newText.matches("^\\d*\\.?\\d*$") || newText.isEmpty()) {
                return change; // 如果是合法的浮点数则允许输入
            }
            return null; // 否则不允许输入
        };
        return new TextFormatter<>(filter);
    }

    public static TextFormatter<String> matchNumberFormatter() {
        // 使用正则表达式限制只能输入正的浮点数
        UnaryOperator<TextFormatter.Change> filter = change -> {
            String newText = change.getControlNewText();
            if (newText.matches("[0-9]*") || newText.isEmpty()) {
                return change; // 如果是合法的浮点数则允许输入
            }
            return null; // 否则不允许输入
        };
        return new TextFormatter<>(filter);
    }
}
