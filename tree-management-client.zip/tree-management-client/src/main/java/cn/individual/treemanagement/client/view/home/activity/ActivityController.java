package cn.individual.treemanagement.client.view.home.activity;

import cn.individual.treemanagement.client.api.ActivityApi;
import cn.individual.treemanagement.client.pojo.vo.ActivityVO;
import javafx.application.Platform;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.concurrent.Task;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.io.IOException;
import java.time.LocalDate;
import java.util.List;

/**
 * @author li
 * @date create in 2025/1/22 13:57
 **/
public class ActivityController {
    @FXML
    public DatePicker startDatePicker;
    @FXML
    public DatePicker endDatePicker;
    @FXML
    public TextField keywordText;
    @FXML
    public Button queryButton;
    @FXML
    public Button organizeActivityButton;
    @FXML
    public TableView<ActivityVO> activityTableView;
    @FXML
    public TableColumn<ActivityVO, String> usernameColumn;
    @FXML
    public TableColumn<ActivityVO, String> topicColumn;
    @FXML
    public TableColumn<ActivityVO, Double> budgetColumn;
    @FXML
    public TableColumn<ActivityVO, Integer> numberColumn;
    @FXML
    public TableColumn<ActivityVO, LocalDate> activityDateColumn;

    private ActivityApi activityApi;

    private List<ActivityVO> activityList;

    private ObjectProperty<LocalDate> startDate;

    private ObjectProperty<LocalDate> endDate;

    private SimpleStringProperty keyword;

    @FXML
    public void activityList(ActionEvent actionEvent) {
        Platform.runLater(activityListTask());
    }

    @FXML
    public void organizeActivity(ActionEvent actionEvent) throws IOException {
        Parent root = FXMLLoader.load(getClass().getClassLoader().getResource("view/home/activity/OrganizeActivityController.fxml"));
        Stage organizeActivityStage = new Stage();
        organizeActivityStage.setTitle("Organize Activity");
        Scene organizeActivityScene = new Scene(root, 500, 600);
        organizeActivityStage.setScene(organizeActivityScene);
        organizeActivityStage.show();
    }

    @FXML
    public void initialize() {
        this.activityApi = new ActivityApi();
        activityList = activityApi.activityList(null, null, null);
        this.bindQueryEvent();
        this.setActivityTableView();
        this.setTableColumns();
    }

    private void bindQueryEvent() {
        startDate = new SimpleObjectProperty<>();
        endDate = new SimpleObjectProperty<>();
        keyword = new SimpleStringProperty();
        startDatePicker.valueProperty().bindBidirectional(startDate);
        endDatePicker.valueProperty().bindBidirectional(endDate);
        keywordText.textProperty().bindBidirectional(keyword);
    }

    private void setActivityTableView() {
        ObservableList<ActivityVO> observableList = FXCollections.observableList(activityList);
        activityTableView.setItems(observableList);
    }

    private void setTableColumns() {
        usernameColumn.setCellValueFactory(new PropertyValueFactory<>("username"));
        topicColumn.setCellValueFactory(new PropertyValueFactory<>("topic"));
        budgetColumn.setCellValueFactory(new PropertyValueFactory<>("budget"));
        numberColumn.setCellValueFactory(new PropertyValueFactory<>("number"));
        activityDateColumn.setCellValueFactory(new PropertyValueFactory<>("activityDate"));
    }

    private Task<List<ActivityVO>> activityListTask() {
        Task<List<ActivityVO>> activityListTask = new Task<List<ActivityVO>>() {
            @Override
            protected List<ActivityVO> call() throws Exception {
                return activityApi.activityList(startDate.get(), endDate.get(), keyword.get());
            }
        };
        activityListTask.setOnSucceeded(event -> {
            activityTableView.getItems().clear();
            activityTableView.getItems().addAll(activityListTask.getValue());
        });
        return activityListTask;
    }
}
