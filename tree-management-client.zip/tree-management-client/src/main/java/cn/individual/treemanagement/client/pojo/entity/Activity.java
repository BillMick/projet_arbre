package cn.individual.treemanagement.client.pojo.entity;

import lombok.Data;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Data
public class Activity implements Serializable {
	/**
	 * 主键id
	 */
	private Long id;
	/**
	 * 用户id
	 */
	private Long userId;
	/**
	 * 活动主题
	 */
	private String topic;
	/**
	 * 活动经费
	 */
	private Double budget;
	/**
	 * 树木id
	 */
	private Long treeId;

	private Integer number;

	private LocalDate activityDate;

	/**
	 * 创建时间
	 */
	private LocalDateTime createTime;
	/**
	 * 更新时间
	 */
	private LocalDateTime updateTime;
}
