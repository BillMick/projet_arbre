package cn.individual.treemanagement.client.api;

import cn.individual.treemanagement.client.pojo.entity.SystemLog;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import cn.individual.treemanagement.client.config.InitConfigurer;
import cn.individual.treemanagement.client.pojo.entity.SystemDues;
import cn.individual.treemanagement.client.pojo.vo.SystemRoleVO;
import cn.individual.treemanagement.client.pojo.vo.SystemUserDuesVO;
import cn.individual.treemanagement.client.pojo.vo.SystemUserVO;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static cn.individual.treemanagement.client.common.UrlPath.*;

/**
 * @author li
 * @date create in 2025/1/17 21:15
 **/
public class AdminApi {

    private final ObjectMapper objectMapper;

    public AdminApi() {
        objectMapper = InitConfigurer.objectMapper;
    }

    public void enableUser(Long userId) {
        MultiValueMap<String, Object> form = new LinkedMultiValueMap<>();
        form.add("userId", userId);
        Request.postRequest(domain + enableApi, form);
    }

    public void disableUser(Long userId) {
        MultiValueMap<String, Object> form = new LinkedMultiValueMap<>();
        form.add("userId", userId);
        Request.postRequest(domain + disableApi, form);
    }

    public void finalizedTree() {
        Request.postRequest(domain + finalizedTreeApi, objectMapper.createObjectNode());
    }

    public List<SystemRoleVO> getRoleList() {
        JsonNode data = Request.postRequest(domain + roleApi, objectMapper.createObjectNode());
        return objectMapper.convertValue(data, objectMapper.getTypeFactory().constructCollectionType(List.class, SystemRoleVO.class));
    }

    public void resetPassword(Long userId) {
        MultiValueMap<String, Object> form = new LinkedMultiValueMap<>();
        form.add("userId", userId);
        Request.postRequest(domain + resetApi, form);
    }

    public void setYearDues(Double yearDues) {
        MultiValueMap<String, Object> form = new LinkedMultiValueMap<>();
        form.add("yearDues", yearDues);
        Request.postRequest(domain + yearDuesApi, form);
    }

    public List<SystemLog> systemLogList(LocalDate startDate, LocalDate endDate) {
        Map<String, Object> form = new HashMap<>();
        form.put("startDate", startDate);
        form.put("endDate", endDate);
        JsonNode data = Request.getRequest(domain + systemLogApi, form);
        return objectMapper.convertValue(data, objectMapper.getTypeFactory().constructCollectionType(List.class, SystemLog.class));
    }

}
