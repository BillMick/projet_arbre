package cn.individual.treemanagement.client.pojo.vo;

import lombok.Data;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * @author li
 * @date create in 2025/1/14 14:12
 **/
@Data
public class TreeOperationVO implements Serializable {

    private String username;
    /**
     * 树木id
     */
    private Long treeId;
    /**
     * 操作:种植、砍伐、提名
     */
    private Integer operate;
    /**
     * 创建时间
     */
    private LocalDateTime createTime;
    /**
     * 更新时间
     */
    private LocalDateTime updateTime;
}
