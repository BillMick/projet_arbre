package cn.individual.treemanagement.client.view.home.paid;

import cn.individual.treemanagement.client.api.DuesApi;
import cn.individual.treemanagement.client.api.UserApi;
import cn.individual.treemanagement.client.common.Constants;
import cn.individual.treemanagement.client.config.InitConfigurer;
import cn.individual.treemanagement.client.control.TipsDialog;
import cn.individual.treemanagement.client.pojo.PaidEnum;
import cn.individual.treemanagement.client.pojo.RoleEnum;
import cn.individual.treemanagement.client.pojo.entity.SystemDues;
import cn.individual.treemanagement.client.pojo.form.DuesForm;
import cn.individual.treemanagement.client.pojo.vo.LoginResult;
import cn.individual.treemanagement.client.pojo.vo.SystemUserDuesVO;
import cn.individual.treemanagement.client.util.LocalCacheUtil;
import javafx.application.Platform;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.concurrent.Task;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import javafx.util.converter.DoubleStringConverter;

import java.io.IOException;
import java.time.LocalDate;
import java.time.Year;
import java.util.List;

/**
 * @author li
 * @date create in 2025/1/23 10:25
 **/
public class PaidController {
    @FXML
    public TextField donateDuesText;

    @FXML
    public Button donateButton;

    @FXML
    public Button becomeButton;

    @FXML
    public Label duesLab;

    @FXML
    public Button payButton;

    @FXML
    public DatePicker startDatePicker;

    @FXML
    public DatePicker endDatePicker;

    @FXML
    public Button queryButton;

    @FXML
    public TableView<SystemUserDuesVO> duesTableview;

    @FXML
    public TableColumn<SystemUserDuesVO, String> usernameColumn;

    @FXML
    public TableColumn<SystemUserDuesVO, Double> duesColumn;

    @FXML
    public TableColumn<SystemUserDuesVO, String> paidColumn;

    @FXML
    public TableColumn<SystemUserDuesVO, Integer> yearColumn;

    @FXML
    public TableColumn<SystemUserDuesVO, LocalDate> createTimeColumn;

    @FXML
    public TableColumn<SystemUserDuesVO, LocalDate> updateTimeColumn;

    private List<SystemUserDuesVO> userDuesList;

    private ObjectProperty<LocalDate> startDate;

    private ObjectProperty<LocalDate> endDate;

    private DuesApi duesApi;

    private UserApi userApi;

    private Double duesValue;

    @FXML
    public void payDuesList(ActionEvent actionEvent) {
        Platform.runLater(userDuesListTask());
    }

    @FXML
    public void donateDues(ActionEvent actionEvent) {
        Platform.runLater(donateDuesTask());
    }

    @FXML
    public void becomeMember(ActionEvent actionEvent) {
        Platform.runLater(becomeMemberTask());
    }

    @FXML
    public void payDues(ActionEvent actionEvent) {
        Platform.runLater(payDuesTask());
    }

    @FXML
    public void initialize() {
        this.userApi = new UserApi();
        this.duesApi = new DuesApi();
        this.userDuesList = duesApi.getSelfDuesList(null, null);
        this.duesValue = duesApi.yearDues();
        this.duesLab.setText("Dues: " + duesValue);
        this.setPayButton();
        this.bindQueryEvent();
        this.setDonateTableView();
        this.setTableColumns();
        this.donateDuesText.setTextFormatter(Constants.matchDoubleFormatter());
        LoginResult loginUser = (LoginResult) LocalCacheUtil.get(Constants.LOGIN_USER);
        if(loginUser.getRoleId().equals(RoleEnum.Guest.getCode())) {
            payButton.setManaged(false);
            duesLab.setManaged(false);
        } else {
            becomeButton.setManaged(false);
        }
    }

    private void bindQueryEvent() {
        startDate = new SimpleObjectProperty<>();
        endDate = new SimpleObjectProperty<>();
        startDatePicker.valueProperty().bindBidirectional(startDate);
        endDatePicker.valueProperty().bindBidirectional(endDate);
    }

    private void setDonateTableView() {
        ObservableList<SystemUserDuesVO> observableList = FXCollections.observableList(userDuesList);
        duesTableview.setItems(observableList);
    }

    private void setTableColumns() {
        usernameColumn.setCellValueFactory(new PropertyValueFactory<>("username"));
        duesColumn.setCellValueFactory(new PropertyValueFactory<>("dues"));
        paidColumn.setCellValueFactory(cellData->{
            Integer paid = cellData.getValue().getPaid();
            PaidEnum paidEnum = PaidEnum.getEnum(paid);
            return new SimpleStringProperty(paidEnum.getName());
        });
        yearColumn.setCellValueFactory(new PropertyValueFactory<>("year"));
        createTimeColumn.setCellValueFactory(new PropertyValueFactory<>("createTime"));
        updateTimeColumn.setCellValueFactory(new PropertyValueFactory<>("updateTime"));
    }

    private void setPayButton() {
        boolean isFullPayDues = userApi.isFullPayDues();
        payButton.setDisable(isFullPayDues);
    }

    private Task<List<SystemUserDuesVO>> userDuesListTask() {
        Task<List<SystemUserDuesVO>> userDuesListTask = new Task<List<SystemUserDuesVO>>() {
            @Override
            protected List<SystemUserDuesVO> call() throws Exception {
                return duesApi.getSelfDuesList(startDate.get(), endDate.get());
            }
        };

        userDuesListTask.setOnSucceeded(event -> {
            duesTableview.getItems().clear();
            duesTableview.getItems().addAll(userDuesListTask.getValue());
        });
        return userDuesListTask;
    }

    private Task<Void> donateDuesTask() {
        Task<Void> donateDuesTask = new Task<Void>() {
            @Override
            protected Void call() throws Exception {
                DuesForm duesForm = new DuesForm();
                Double dues = Double.parseDouble(donateDuesText.getText());
                duesForm.setDues(dues);
                duesForm.setYear(Year.now().getValue());
                duesApi.donateDues(duesForm);
                return null;
            }
        };
        donateDuesTask.setOnSucceeded(event -> {
            duesTableview.getItems().clear();
            this.userDuesList = duesApi.getSelfDuesList(startDate.get(), endDate.get());
            duesTableview.getItems().addAll(userDuesList);
            TipsDialog tipsDialog = new TipsDialog("Thank you for your donation!");
            tipsDialog.show();
        });
        return donateDuesTask;
    }

    private Task<Void> becomeMemberTask() {
        Task<Void> becomeMemberTask = new Task<Void>() {
            @Override
            protected Void call() throws Exception {
                userApi.becomeMember();
                return null;
            }
        };
        becomeMemberTask.setOnSucceeded(event -> {
            // todo重新加载组件
            TipsDialog tipsDialog = new TipsDialog("Thank you for your become member");
            tipsDialog.show();
            refreshWindow();
        });
        return becomeMemberTask;
    }

    private Task<Void> payDuesTask() {
        Task<Void> payDuesTask = new Task<Void>() {
            @Override
            protected Void call() throws Exception {
                DuesForm duesForm = new DuesForm();
                duesForm.setDues(duesValue);
                duesForm.setYear(Year.now().getValue());
                userApi.renewal(duesForm);
                return null;
            }
        };
        payDuesTask.setOnSucceeded(event -> {
            duesTableview.getItems().clear();
            this.userDuesList = duesApi.getSelfDuesList(startDate.get(), endDate.get());
            duesTableview.getItems().addAll(userDuesList);
        });
        return payDuesTask;
    }

    private void refreshWindow() {
        try {
            Stage stage = (Stage) becomeButton.getScene().getWindow();
            stage.hide();
            Parent root = FXMLLoader.load(getClass().getClassLoader().getResource("view/home/HomeController.fxml"));
            Stage homeStage = new Stage();
            homeStage.setTitle("Tree Management");
            Scene scene = new Scene(root, 1200, 800);
            homeStage.setScene(scene);
            homeStage.show();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
