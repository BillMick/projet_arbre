# projet_arbre
L'objet de ce projet est de développer de petites applications de gestion pour une association d'amateurs d'arbres.

# Particularités fonctionnelles
# # Gestion des années budgétaires
L'association n'a pas directement accès à la configuration de son année d'exercice budgétaire. A sa création, on définit par défaut ladite année (année courante du système, soit 2025). Le déclenchement de la fin de son exercice budgétaire implique l'ouverture d'une nouvelle année qui est la précédente augmentée de 1.
Faudrait-il exiger que ce soit la municipalité qui lance la fin des exercices budgétaires ??? Si non, il aurait des décalages entre les années d'exercice des associations existantes...