package com.individual.treemanagement.view.login;

import com.individual.treemanagement.api.ActivityApi;
import com.individual.treemanagement.api.TreeApi;
import com.individual.treemanagement.api.UserApi;
import com.individual.treemanagement.common.Controls;
import com.individual.treemanagement.config.InitConfigurer;
import com.individual.treemanagement.dto.pojo.form.ActivityForm;
import com.individual.treemanagement.dto.pojo.form.UserForm;
import com.individual.treemanagement.dto.pojo.vo.OutstandingTreeVO;
import javafx.application.Application;
import javafx.concurrent.Task;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.util.List;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.function.UnaryOperator;
import java.util.stream.Collectors;

/**
 * @author li
 * @date create in 2025/1/17 20:32
 **/
public class RegisterWindow extends Application {
    private BorderPane borderPane;
    private UserForm userForm;
    private UserApi userApi;
    private ThreadPoolExecutor executor;

    public RegisterWindow() {
        borderPane = new BorderPane();
        userForm = new UserForm();
        userApi = new UserApi();
        executor = InitConfigurer.executor;
    }

    @Override
    public void start(Stage primaryStage) throws Exception {
        VBox vbox = new VBox();
        vbox.getChildren().addAll(
                createUsernameBar(),
                createFirstNameBar(),
                createLastNameBar(),
                createBirthdayBar(),
                createAddressBar());

        Button updateButton = Controls.button("Submit", event -> {
            executor.execute(addUserTask());
            primaryStage.close();
        });

        Button cancelButton = Controls.button("Cancel", event -> {
            primaryStage.close();
        });

        HBox buttonBar = new HBox();
        buttonBar.getChildren().addAll(updateButton, cancelButton);
        vbox.getChildren().add(buttonBar);
        borderPane.setCenter(vbox);

        Scene scene = new Scene(borderPane, 500, 600);
        // 加载css文件
        scene.getStylesheets().add(getClass().getClassLoader().getResource("TreeDialog.css").toExternalForm());
        primaryStage.setTitle("Add User");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private Task<Void> addUserTask() {
        Task<Void> addUserTask = new Task<Void>() {
            @Override
            protected Void call() throws Exception {
                userApi.registerUser(userForm);
                return null;
            }
        };
        addUserTask.setOnSucceeded(e -> {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Success");
            alert.setHeaderText(null);
            alert.setContentText("User successfully registered!");
        });
        return addUserTask;
    }

    private AnchorPane createUsernameBar() {
        AnchorPane usernameBar = new AnchorPane();
        Label treeLabel = new Label("Username");
        TextField usernameTextField = new TextField();
        treeLabel.setLabelFor(usernameTextField);
        usernameTextField.textProperty().addListener((observable, oldValue, newValue) -> {
            userForm.setUsername(newValue);
        });
        Label requiredLabel = new Label("*");
        requiredLabel.setStyle("-fx-text-fill: red; -fx-font-weight: bold; -fx-font-size: 14px;");
        this.setAnchor(treeLabel, usernameTextField, requiredLabel);
        usernameBar.getChildren().addAll(treeLabel, usernameTextField, requiredLabel);
        return usernameBar;
    }

    private AnchorPane createFirstNameBar() {
        AnchorPane firstNameBar = new AnchorPane();
        Label firstNameLabel = new Label("FirstName");
        TextField firstNameField = new TextField();
        Label requiredLabel = new Label("*");
        requiredLabel.setStyle("-fx-text-fill: red; -fx-font-weight: bold; -fx-font-size: 14px;");
        firstNameField.textProperty().addListener((observable, oldValue, newValue) -> {
            userForm.setFirstName(newValue);
        });
        this.setAnchor(firstNameLabel, firstNameField, requiredLabel);
        firstNameBar.getChildren().addAll(firstNameLabel, firstNameField, requiredLabel);
        return firstNameBar;
    }

    private AnchorPane createLastNameBar() {
        AnchorPane lastNameBar = new AnchorPane();
        Label lastNameLabel = new Label("LastName");
        TextField lastNameField = new TextField();
        Label requiredLabel = new Label("*");
        requiredLabel.setStyle("-fx-text-fill: red; -fx-font-weight: bold; -fx-font-size: 14px;");
        lastNameField.textProperty().addListener((observable, oldValue, newValue) -> {
            userForm.setLastName(newValue);
        });
        this.setAnchor(lastNameLabel, lastNameField, requiredLabel);
        lastNameBar.getChildren().addAll(lastNameLabel, lastNameField, requiredLabel);
        return lastNameBar;
    }

    private AnchorPane createBirthdayBar() {
        AnchorPane birthdayBar = new AnchorPane();
        Label birthdayLabel = new Label("Birthday");
        DatePicker birthdayPicker = new DatePicker();
        birthdayLabel.setLabelFor(birthdayPicker);
        birthdayPicker.setOnAction(event -> {
            userForm.setBirthday(birthdayPicker.getValue());
        });
        Label requiredLabel = new Label("*");
        requiredLabel.setStyle("-fx-text-fill: red; -fx-font-weight: bold; -fx-font-size: 14px;");
        this.setAnchor(birthdayLabel, birthdayPicker, requiredLabel);
        birthdayBar.getChildren().addAll(birthdayLabel, birthdayPicker, requiredLabel);
        return birthdayBar;
    }

    private AnchorPane createAddressBar() {
        AnchorPane addressBar = new AnchorPane();
        Label addressDateLabel = new Label("Address");
        TextField addressField = new TextField();
        Label requiredLabel = new Label("*");
        requiredLabel.setStyle("-fx-text-fill: red; -fx-font-weight: bold; -fx-font-size: 14px;");
        addressField.textProperty().addListener((observable, oldValue, newValue) -> {
            userForm.setAddress(newValue);
        });
        this.setAnchor(addressDateLabel, addressField, requiredLabel);
        addressBar.getChildren().addAll(addressDateLabel, addressField, requiredLabel);
        return addressBar;
    }



    public void setAnchor(Node title, Node input, Node required) {
        AnchorPane.setLeftAnchor(title, 10.0);
        AnchorPane.setLeftAnchor(input, 100.0);
        AnchorPane.setLeftAnchor(required, 350.0);
    }
}
