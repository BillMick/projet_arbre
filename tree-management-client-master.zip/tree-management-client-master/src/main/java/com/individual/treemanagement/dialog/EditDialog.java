package com.individual.treemanagement.dialog;

import javafx.application.Application;
import javafx.stage.Stage;

/**
 * @author li
 * @date create in 2025/1/18 14:07
 **/
public class EditDialog extends Application {


    @Override
    public void start(Stage primaryStage) throws Exception {

    }
}
