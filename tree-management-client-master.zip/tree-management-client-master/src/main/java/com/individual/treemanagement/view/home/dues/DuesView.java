package com.individual.treemanagement.view.home.dues;

import com.individual.treemanagement.api.AdminApi;
import com.individual.treemanagement.api.TreeApi;
import com.individual.treemanagement.common.*;
import com.individual.treemanagement.config.InitConfigurer;
import com.individual.treemanagement.dto.pojo.vo.OutstandingTreeVO;
import com.individual.treemanagement.dto.pojo.vo.SystemUserDuesVO;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.concurrent.Task;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.function.UnaryOperator;

/**
 * @author li
 * @date create in 2025/1/17 20:33
 **/
public class DuesView {
    private TableView<SystemUserDuesVO> userDuesTableView;
    private HBox headerPane;
    private AdminApi adminApi;
    private LocalDate startDate;
    private LocalDate endDate;
    private Integer paid;
    private List<SystemUserDuesVO> userDuesList;
    private ThreadPoolExecutor executor;
    private Double yearDues;

    public DuesView() {
        adminApi = new AdminApi();
        userDuesList = adminApi.getUserDuesList(startDate, endDate, paid);
        executor = InitConfigurer.executor;
        userDuesTableView = userDuesTableView();
        headerPane = headerView();
    }

    public VBox createTreeView() {
        VBox treeView = new VBox();
        treeView.setSpacing(10.0);
        treeView.getChildren().addAll(headerPane, userDuesTableView);
        return treeView;
    }

    private HBox headerView() {
        HBox headerView = new HBox();
        headerView.setSpacing(5.0);

        DatePicker startDatePicker = Controls.startDatePicker(event -> {
            startDate =  ((DatePicker) event.getSource()).getValue();
        });


        DatePicker endDatePicker = Controls.endDatePicker(event -> {
            endDate =  ((DatePicker) event.getSource()).getValue();
        });


        ComboBox<String> paidComboBox = Controls.statusComboBox(PaidEnum.paidEnumNames(), event -> {
            String selectedItem = ((ComboBox<String>) event.getSource()).getSelectionModel().getSelectedItem();
            Integer code = PaidEnum.valueOf(selectedItem).getCode();
            paid = code;
        });

        Button submitButton = Controls.button("query", event -> {
            Task<List<SystemUserDuesVO>> treeListTask = userDuesListTask();
            executor.execute(treeListTask);
        });

        Label duesLabel = new Label("Dues");

        TextField duesTextField = new TextField();
        duesLabel.setLabelFor(duesTextField);
        duesTextField.setTextFormatter(matchDoubleFormatter());
        duesTextField.textProperty().addListener((observable, oldValue, newValue) -> {
            yearDues = Double.valueOf(newValue);
        });
        Button setDuesButton = Controls.button("set", event -> {
            executor.execute(setDuesTask());
        });
        headerView.getChildren().addAll(startDatePicker, endDatePicker, paidComboBox, submitButton);
        if(LocalStorage.role.equals(RoleEnum.Admin)) {
            headerView.getChildren().addAll(duesLabel, duesTextField, setDuesButton);
        }
        return headerView;
    }

    private Task<List<SystemUserDuesVO>> userDuesListTask() {
        Task<List<SystemUserDuesVO>> treeListTask = new Task<List<SystemUserDuesVO>>() {
            @Override
            protected List<SystemUserDuesVO> call() throws Exception {
                userDuesList = adminApi.getUserDuesList(startDate, endDate, paid);
                return userDuesList;
            }
        };
        treeListTask.setOnSucceeded(event -> {
            userDuesList = treeListTask.getValue();
            userDuesTableView.setItems(FXCollections.observableList(userDuesList));
        });
        return treeListTask;
    }

    private Task<Void> setDuesTask() {
        Task<Void> setDuesTask = new Task<Void>() {
            @Override
            protected Void call() throws Exception {
                adminApi.setYearDues(yearDues);
                return null;
            }
        };
        setDuesTask.setOnSucceeded(event -> {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Set Dues");
            alert.setHeaderText(null);
            alert.setContentText("Dues set to " + yearDues);
        });
        return setDuesTask;
    }

    private TableView<SystemUserDuesVO> userDuesTableView() {
        ObservableList<SystemUserDuesVO> userDuesObservableList = FXCollections.observableList(userDuesList);
        TableView<SystemUserDuesVO> userDuesTableView = new TableView<>(userDuesObservableList);
        userDuesTableView.getColumns().addAll(
                usernameColumn(),
                duesColumn(),
                paidColumn(),
                yearColumn(),
                createTimeColumn(),
                updateTimeColumn());
        return userDuesTableView;
    }

    private TableColumn<SystemUserDuesVO, String> usernameColumn() {
        TableColumn<SystemUserDuesVO, String> usernameColumn = new TableColumn<>("Username");
        usernameColumn.setCellValueFactory(new PropertyValueFactory<>("username"));
        return usernameColumn;
    }

    private TableColumn<SystemUserDuesVO, Double> duesColumn() {
        TableColumn<SystemUserDuesVO, Double> duesColumn = new TableColumn<>("Dues");
        duesColumn.setCellValueFactory(new PropertyValueFactory<>("dues"));
        return duesColumn;
    }

    private TableColumn<SystemUserDuesVO, Integer> paidColumn() {
        TableColumn<SystemUserDuesVO, Integer> paidColumn = new TableColumn<>("Paid");
        paidColumn.setCellValueFactory(new PropertyValueFactory<>("paid"));
        return paidColumn;
    }

    private TableColumn<SystemUserDuesVO, Integer> yearColumn() {
        TableColumn<SystemUserDuesVO, Integer> yearColumn = new TableColumn<>("Year");
        yearColumn.setCellValueFactory(new PropertyValueFactory<>("year"));
        return yearColumn;
    }


    private TableColumn<SystemUserDuesVO, LocalDateTime> createTimeColumn() {
        TableColumn<SystemUserDuesVO, LocalDateTime> createTimeColumn = new TableColumn<>("Create Time");
        createTimeColumn.setCellValueFactory(new PropertyValueFactory<>("createTime"));
        return createTimeColumn;
    }

    private TableColumn<SystemUserDuesVO, LocalDateTime> updateTimeColumn() {
        TableColumn<SystemUserDuesVO, LocalDateTime> updateTimeColumn = new TableColumn<>("Update Time");
        updateTimeColumn.setCellValueFactory(new PropertyValueFactory<>("updateTime"));
        return updateTimeColumn;
    }

    private static TextFormatter<String> matchDoubleFormatter() {
        // 使用正则表达式限制只能输入正的浮点数
        UnaryOperator<TextFormatter.Change> filter = change -> {
            String newText = change.getControlNewText();
            if (newText.matches("^\\d*\\.?\\d*$") || newText.isEmpty()) {
                return change; // 如果是合法的浮点数则允许输入
            }
            return null; // 否则不允许输入
        };
        return new TextFormatter<>(filter);
    }
}
