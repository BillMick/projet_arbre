package com.individual.treemanagement.api;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.individual.treemanagement.common.LocalStorage;
import com.individual.treemanagement.common.RoleEnum;
import com.individual.treemanagement.config.InitConfigurer;
import com.individual.treemanagement.dto.pojo.form.DuesForm;
import com.individual.treemanagement.dto.pojo.form.LoginForm;
import com.individual.treemanagement.dto.pojo.form.PasswordForm;
import com.individual.treemanagement.dto.pojo.form.UserForm;
import com.individual.treemanagement.dto.pojo.vo.LoginResult;

import static com.individual.treemanagement.common.UrlConstants.*;
import static com.individual.treemanagement.common.UrlConstants.changePasswordApi;

/**
 * @author li
 * @date create in 2025/1/17 21:14
 **/
public class UserApi {

    private final ObjectMapper objectMapper;

    public UserApi() {
        objectMapper = InitConfigurer.objectMapper;
    }

    public LoginResult login(String username, String password) {
        LoginForm loginForm = new LoginForm();
        loginForm.setUsername(username);
        loginForm.setPassword(password);
        JsonNode form = objectMapper.valueToTree(loginForm);
        JsonNode data = Request.postRequest(domain + loginApi, form);
        LoginResult loginResult = objectMapper.convertValue(data, LoginResult.class);
        LocalStorage.accessToken = loginResult.getAccessToken();
        LocalStorage.role = RoleEnum.getRoleByCode(loginResult.getRoleId());
        return loginResult;
    }

    public void logout() {
        LocalStorage.accessToken = "";
        Request.postRequest(domain + logoutApi, objectMapper.createObjectNode());
    }

    public void registerUser(UserForm userForm) {
        JsonNode form = objectMapper.valueToTree(userForm);
        Request.postRequest(domain + registerApi, form);
    }

    public void becomeMember() {
        Request.postRequest(domain + becomeMemberApi, objectMapper.createObjectNode());
    }

    public void renewal(DuesForm form) {
        JsonNode formData = objectMapper.valueToTree(form);
        Request.postRequest(domain + renewalApi, formData);
    }

    public void changePassword(PasswordForm form) {
        JsonNode formData = objectMapper.valueToTree(form);
        Request.postRequest(domain + changePasswordApi, formData);
    }
}
