package com.individual.treemanagement.config;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateDeserializer;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateTimeDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateSerializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateTimeSerializer;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.TimeZone;
import java.util.concurrent.*;

/**
 * @author li
 * @date create in 2025/1/17 21:17
 **/
public class InitConfigurer {

    private static final DateTimeFormatter LOCAL_DATE_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd");

    private static final DateTimeFormatter LOCAL_DATE_TIME_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    public static ObjectMapper objectMapper = ObjectMapperEnum.INSTANCE.getObjectMapper();

    public static ThreadPoolExecutor executor = ThreadPoolEnum.INSTANCE.getInstance();

    private enum ObjectMapperEnum {
        INSTANCE;
        private final ObjectMapper objectMapper;
        ObjectMapperEnum() {
            objectMapper = new ObjectMapper();
            objectMapper.setTimeZone(TimeZone.getTimeZone("Asia/Shanghai"));
            objectMapper.setDateFormat(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss"));
            JavaTimeModule javaTimeModule = new JavaTimeModule();
            javaTimeModule.addSerializer(LocalDate.class, new LocalDateSerializer(LOCAL_DATE_FORMATTER));
            javaTimeModule.addDeserializer(LocalDate.class, new LocalDateDeserializer(LOCAL_DATE_FORMATTER));
            javaTimeModule.addSerializer(LocalDateTime.class, new LocalDateTimeSerializer(LOCAL_DATE_TIME_FORMATTER));
            javaTimeModule.addDeserializer(LocalDateTime.class, new LocalDateTimeDeserializer(LOCAL_DATE_TIME_FORMATTER));
            objectMapper.registerModule(javaTimeModule);
        }

        public ObjectMapper getObjectMapper() {
            return objectMapper;
        }
    }

    private enum ThreadPoolEnum {
        /**
         * 实例
         */
        INSTANCE;
        /**
         * 线程池单例
         */
        private final ThreadPoolExecutor es;

        /**
         * 核心线程数量
         */
        final int corePoolSize = Runtime.getRuntime().availableProcessors() + 1;

        /**
         * 最大线程数量
         */
        final int maximumPoolSize = Runtime.getRuntime().availableProcessors() * 2 + 1;

        /**
         * 线程的最大存活时间
         */
        final int keepAliveTime = 10;

        /**
         * 时间单位
         */
        final TimeUnit unit = TimeUnit.SECONDS;

        /**
         * 任务队列
         */
        final BlockingQueue<Runnable> workQueue = new LinkedBlockingQueue<>(22);

        /**
         * 线程工厂
         */
        final ThreadFactory threadFactory = Executors.defaultThreadFactory();

        /**
         * 任务拒绝策略
         */
        final RejectedExecutionHandler handler = new ThreadPoolExecutor.CallerRunsPolicy();

        /**
         * 枚举 (构造器默认为私有）
         */
        ThreadPoolEnum() {
            es = new ThreadPoolExecutor(
                    corePoolSize,
                    maximumPoolSize,
                    keepAliveTime,
                    unit,
                    workQueue,
                    threadFactory,
                    handler
            );
        }


        /**
         * 公有方法
         *
         * @return ExecutorService
         */
        public ThreadPoolExecutor getInstance() {
            return es;
        }
    }
}
