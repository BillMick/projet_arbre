package com.individual.treemanagement.dto.pojo.vo;

import lombok.Data;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * @author li
 * @date create in 2025/1/16 22:18
 **/
@Data
public class SystemUserDuesVO implements Serializable {
    private String username;
    /**
     * 会费
     */
    private Double dues;
    /**
     * 是否支付
     */
    private Integer paid;
    /**
     * 年度
     */
    private Integer year;
    /**
     * 创建时间
     */
    private LocalDateTime createTime;
    /**
     * 更新时间
     */
    private LocalDateTime updateTime;
}
