package com.individual.treemanagement.api;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.individual.treemanagement.config.InitConfigurer;
import com.individual.treemanagement.dto.pojo.form.DuesForm;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

import java.util.HashMap;

import static com.individual.treemanagement.common.UrlConstants.*;

/**
 * @author li
 * @date create in 2025/1/17 21:50
 **/
public class DuesApi {

    private final ObjectMapper objectMapper;

    public DuesApi() {
        objectMapper = InitConfigurer.objectMapper;
    }

    public void donateDues(DuesForm form) {
        JsonNode formNode = objectMapper.valueToTree(form);
        Request.postRequest(domain + donateApi, formNode);
    }

    public Double yearDues() {
        JsonNode data = Request.getRequest(domain + yearDonateApi, new HashMap<>());
        return objectMapper.convertValue(data, Double.class);
    }
}
