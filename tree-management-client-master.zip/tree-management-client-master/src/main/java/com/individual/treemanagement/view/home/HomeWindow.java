package com.individual.treemanagement.view.home;

import com.individual.treemanagement.api.DuesApi;
import com.individual.treemanagement.api.Request;
import com.individual.treemanagement.api.UserApi;
import com.individual.treemanagement.common.Controls;
import com.individual.treemanagement.common.LocalStorage;
import com.individual.treemanagement.common.RoleEnum;
import com.individual.treemanagement.config.InitConfigurer;
import com.individual.treemanagement.dto.pojo.form.DuesForm;
import com.individual.treemanagement.view.home.activity.ActivityView;
import com.individual.treemanagement.view.home.dues.DuesView;
import com.individual.treemanagement.view.home.outstanding.OutstandingTreeView;
import com.individual.treemanagement.view.home.tree.TreeView;
import com.individual.treemanagement.view.home.user.UserView;
import com.individual.treemanagement.view.home.vote.VoteView;
import javafx.application.Application;
import javafx.concurrent.Task;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.time.Year;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.function.UnaryOperator;

/**
 * @author li
 * @date create in 2025/1/17 15:26
 **/
public class HomeWindow extends Application {

    private final BorderPane borderPane;
    private final TextField duesTextField;
    private final Button donateButton;
    private final DuesApi duesApi;
    private final ThreadPoolExecutor executor;
    private final Button userButton;
    private final Button treeButton;
    private final Button activityButton;
    private final Button outstandingTreeButton;
    private final Button duesButton;
    private final Double yearDues;
    private final UserApi userApi;
    private final Button voteButton;

    public HomeWindow() {
        borderPane = new BorderPane();
        duesTextField = duesTextField();
        donateButton = donateButton();
        duesApi = new DuesApi();
        executor = InitConfigurer.executor;
        userButton = userButton(borderPane);
        treeButton = treeButton(borderPane);
        activityButton = activityButton(borderPane);
        outstandingTreeButton = outstandingTreeButton(borderPane);
        voteButton = voteButton(borderPane);
        duesButton = duesButton(borderPane);
        yearDues = duesApi.yearDues();
        userApi = new UserApi();
    }

    @Override
    public void start(Stage primaryStage) throws Exception {
        VBox leftNavBar = this.createVBox();
        leftNavBar.getStyleClass().add("left-nav-bar");  // 添加CSS类
        borderPane.setLeft(leftNavBar);
        HBox topBar = new HBox(20);
        topBar.setPadding(new Insets(20, 20, 20, 20));
        topBar.getStyleClass().add("top-bar");  // 添加CSS类
        topBar.getChildren().addAll(duesTextField(), donateButton());
        if(LocalStorage.role.equals(RoleEnum.Guest)) {
            topBar.getChildren().add(becomeMember());
        } else {
            topBar.getChildren().add(payDuesButton());
        }
        borderPane.setTop(topBar);
        treeButton.fire();
        Scene scene = new Scene(borderPane, 1100, 900);
        scene.getStylesheets().add(getClass().getClassLoader().getResource("HomeWindowStyle.css").toExternalForm());  // 加载CSS样式
        primaryStage.setTitle("Home Page");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private VBox createVBox() {
        VBox leftNavBar = new VBox(20);
        leftNavBar.setPadding(new Insets(30));
        leftNavBar.getStyleClass().add("left-nav-bar");  // 添加CSS类
        leftNavBar.getChildren().addAll(treeButton, outstandingTreeButton, activityButton);
        if(!LocalStorage.role.equals(RoleEnum.Guest)) {
            leftNavBar.getChildren().addAll(userButton, voteButton, duesButton);
        }
        return leftNavBar;
    }

    private TextField duesTextField() {
        TextField duesTextField = new TextField();
        duesTextField.setPromptText("Enter Dues Amount");
        duesTextField.getStyleClass().add("text-field");  // 添加CSS类

        UnaryOperator<TextFormatter.Change> filter = change -> {
            String text = change.getControlNewText();
            if(text.matches("[0-9]*")) {
                return change;
            }
            return null;
        };

        TextFormatter<String> textFormatter = new TextFormatter<>(filter);
        duesTextField.setTextFormatter(textFormatter);
        return duesTextField;
    }

    private Button donateButton() {
        Button donateButton = new Button("Donate Dues");
        donateButton.getStyleClass().add("button");  // 添加CSS类
        donateButton.setOnAction(event -> {
            String duesString = duesTextField.getText();
            if (duesString == null || duesString.isEmpty()) {
                showError("Please enter a valid dues amount.");
                return;
            }
            double dues = Double.parseDouble(duesString);
            if (dues <= 0) {
                showError("Please enter a valid dues amount.");
            } else {
                executor.execute(donateTask(dues));
            }
        });
        return donateButton;
    }


    private Task<Void> donateTask(Double dues) {
        Task<Void> donateTask = new Task<Void>() {
            @Override
            protected Void call() throws Exception {
                Integer year = Year.now().getValue();
                DuesForm form = new DuesForm();
                form.setDues(dues);
                form.setYear(year);
                duesApi.donateDues(form);
                return null;
            }
        };
        donateTask.setOnSucceeded(event -> {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Tips");
            alert.setContentText("Thank you for your donation.");
            alert.showAndWait();
        });
        return donateTask;
    }

    private void showError(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Error");
        alert.setContentText(message);
        alert.showAndWait();
    }

    private Button userButton(BorderPane borderPane) {
        Button userButton = new Button("User");
        userButton.setOnAction(event -> {
            // 初始化页面
            UserView userView = new UserView();
            VBox vBox = userView.creatUserView();
            borderPane.setCenter(vBox);
        });
        return userButton;
    }

    private Button treeButton(BorderPane borderPane) {
        Button treeButton = new Button("Tree");
        treeButton.setOnAction(event -> {
            TreeView treeView = new TreeView();
            VBox vBox = treeView.createTreeView();
            borderPane.setCenter(vBox);
        });
        return treeButton;
    }

    private Button activityButton(BorderPane borderPane) {
        Button activityButton = new Button("Activity");
        activityButton.setOnAction(event -> {
            ActivityView activityView = new ActivityView();
            VBox vBox = activityView.createActivityView();
            borderPane.setCenter(vBox);
        });
        return activityButton;
    }

    private Button outstandingTreeButton(BorderPane borderPane) {
        Button outstandingTreeButton = new Button("Outstanding Tree");
        outstandingTreeButton.setOnAction(event -> {
            OutstandingTreeView outstandingTreeView = new OutstandingTreeView();
            VBox vBox = outstandingTreeView.createTreeView();
            borderPane.setCenter(vBox);
        });
        return outstandingTreeButton;
    }

    public Button voteButton(BorderPane borderPane) {
        Button voteButton = new Button("Vote");
        voteButton.setOnAction(event -> {
            VoteView voteView = new VoteView();
            VBox vBox = voteView.createTreeView();
            borderPane.setCenter(vBox);
        });
        return voteButton;
    }

    private Button duesButton(BorderPane borderPane) {
        Button duesButton = Controls.button("Dues", event -> {
            DuesView duesView = new DuesView();
            VBox vBox = duesView.createTreeView();
            borderPane.setCenter(vBox);
        });
        return duesButton;
    }

    private Button payDuesButton() {
        Label duesLabel = new Label(yearDues.toString());
        Button payDuesButton = new Button("Pay Dues");
        duesLabel.setLabelFor(payDuesButton);
        payDuesButton.setOnAction(event -> {
            executor.execute(payDuesTask());
        });
        return payDuesButton;
    }

    private Task<Void> payDuesTask() {
        Task<Void> payDuesTask = new Task<Void>() {
            @Override
            protected Void call() throws Exception {
                DuesForm duesForm = new DuesForm();
                duesForm.setDues(yearDues);
                duesForm.setYear(Year.now().getValue());
                userApi.renewal(duesForm);
                return null;
            }
        };
        payDuesTask.setOnSucceeded(event -> {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Tips");
            alert.setContentText("Thank you for your donation.");
            alert.showAndWait();
        });
        return payDuesTask;
    }

    private Button becomeMember() {
        Button becomeMemberButton = new Button("Become Member");
        becomeMemberButton.setOnAction(event -> {
            executor.execute(becomeMemberTask());
        });
        return becomeMemberButton;
    }

    private Task<Void> becomeMemberTask() {
        Task<Void> becomeMemberTask = new Task<Void>() {
            @Override
            protected Void call() throws Exception {
                userApi.becomeMember();
                return null;
            }
        };
        becomeMemberTask.setOnSucceeded(event -> {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Tips");
            alert.setContentText("Thank you for your become member");
            alert.showAndWait();
        });
        return becomeMemberTask;
    }

    public Button renewalButton() {
        Label duesLabel = new Label(yearDues.toString());
        Button renewalButton = new Button("Renewal Member");
        duesLabel.setLabelFor(renewalButton);
        renewalButton.setOnAction(event -> {
            DuesForm duesForm = new DuesForm();
            duesForm.setDues(yearDues);
            duesForm.setYear(Year.now().getValue());
            userApi.renewal(duesForm);
        });
        return renewalButton;
    }
}
