package com.individual.treemanagement.view.login;

import com.individual.treemanagement.api.UserApi;
import com.individual.treemanagement.dto.pojo.vo.LoginResult;
import com.individual.treemanagement.view.home.HomeWindow;
import javafx.application.Application;
import javafx.concurrent.Task;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.scene.text.Font;
import javafx.stage.Stage;

import java.util.concurrent.CompletableFuture;

import static com.individual.treemanagement.common.LocalStorage.loginResult;

/**
 * @author li
 * @date create in 2025/1/17 15:25
 **/
public class LoginWindow extends Application {

    private final UserApi userApi;

    public LoginWindow() {
        this.userApi = new UserApi();
    }

    @Override
    public void start(Stage primaryStage) throws Exception {
        // 创建一个 GridPane 布局，设置对齐方式和间距
        GridPane grid = new GridPane();
        grid.setAlignment(Pos.CENTER);
        grid.setHgap(10);
        grid.setVgap(10);

        // 设置背景颜色
        grid.setStyle("-fx-background-color: #f4f4f4;");

        // 创建控件
        Label userLabel = new Label("Username:");
        userLabel.setFont(Font.font("Arial", 14));
        TextField userTextField = new TextField();
        userTextField.setPromptText("Enter your username");

        Label passwordLabel = new Label("Password:");
        passwordLabel.setFont(Font.font("Arial", 14));
        PasswordField passwordField = new PasswordField();
        passwordField.setPromptText("Enter your password");

        Button loginButton = getLoginButton(primaryStage, userTextField, passwordField);
        Button registerButton = getRegisterButton();

        // 将控件添加到 GridPane
        grid.add(userLabel, 0, 0);
        grid.add(userTextField, 1, 0);
        grid.add(passwordLabel, 0, 1);
        grid.add(passwordField, 1, 1);
        grid.add(loginButton, 0, 2);
        grid.add(registerButton, 1, 2);

        // 创建场景并设置样式
        Scene scene = new Scene(grid, 500, 400);
        scene.getStylesheets().add(getClass().getClassLoader().getResource("LoginWindowStyle.css").toExternalForm()); // 使用外部 CSS 文件
        primaryStage.setTitle("Login Page");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private Button getLoginButton(Stage primaryStage, TextField userTextField, PasswordField passwordField) {
        Button loginButton = new Button("Login");
        loginButton.setStyle("-fx-background-color: #4CAF50; -fx-text-fill: white; -fx-font-size: 14px;");
        loginButton.setOnAction(event -> {
            Task<LoginResult> task = this.getLoginTask(primaryStage, userTextField, passwordField);
            CompletableFuture.runAsync(task);
        });
        return loginButton;
    }

    private Task<LoginResult> getLoginTask(Stage primaryStage, TextField userTextField, PasswordField passwordField) {
        Task<LoginResult> task = new Task<LoginResult>() {
            @Override
            protected LoginResult call() throws Exception {
                String username = userTextField.getText();
                String password = passwordField.getText();
                return userApi.login(username, password);
            }
        };

        task.setOnSucceeded(e->{
            loginResult = task.getValue();
            this.routeToHome(primaryStage);
        });
        return task;
    }

    private Button getRegisterButton() {
        Button registerButton = new Button("Register");
        registerButton.setStyle("-fx-background-color: #4CAF50; -fx-text-fill: white; -fx-font-size: 14px;");
        registerButton.setOnAction(event -> {
            try {
                Stage stage = new Stage();
                RegisterWindow registerWindow = new RegisterWindow();
                registerWindow.start(stage);
                stage.show();
            } catch (Exception e) {
                throw new RuntimeException(e);
            }

        });
        return registerButton;
    }

    private void showErrorDialog(String errorMessage) {
        // Create an alert dialog to show the error
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Request Error");
        alert.setHeaderText("An error occurred during the request");
        alert.setContentText(errorMessage);

        alert.showAndWait();
    }

    private void routeToHome(Stage loginStage) {
        try {
            loginStage.hide();
            HomeWindow homeWindow = new HomeWindow();
            Stage stage = new Stage();
            homeWindow.start(stage);
            stage.show();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

}
