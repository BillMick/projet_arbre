package com.individual.treemanagement.view.home.activity;

import com.individual.treemanagement.api.ActivityApi;
import com.individual.treemanagement.common.Controls;
import com.individual.treemanagement.config.InitConfigurer;
import com.individual.treemanagement.dto.pojo.vo.ActivityVO;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.concurrent.Task;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.util.Callback;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ThreadPoolExecutor;

/**
 * @author li
 * @date create in 2025/1/17 20:33
 **/
public class ActivityView {

    private ActivityApi activityApi;
    private TableView<ActivityVO> activityTableView;
    private HBox headerPane;
    private SimpleStringProperty keyword;
    private LocalDate startDate;
    private LocalDate endDate;
    private List<ActivityVO> activityList;
    private ThreadPoolExecutor executor;

    public ActivityView() {
        activityApi = new ActivityApi();
        keyword = new SimpleStringProperty();
        activityList = activityApi.activityList(startDate, endDate, keyword.get());
        headerPane = headerView();
        activityTableView = activityTableView();
        executor = InitConfigurer.executor;
    }

    public VBox createActivityView() {
        VBox activityView = new VBox();
        activityView.setSpacing(10.0);
        activityView.getChildren().addAll(headerPane, activityTableView);
        return activityView;
    }

    private HBox headerView() {
        HBox headerView = new HBox();
        headerView.setSpacing(5.0);
        DatePicker startDatePicker = Controls.startDatePicker(event -> {
            startDate =  ((DatePicker) event.getSource()).getValue();
        });
        DatePicker endDatePicker = Controls.endDatePicker(event -> {
            endDate =  ((DatePicker) event.getSource()).getValue();
        });
        TextField keywordTextField = Controls.keywordTextField(keyword);
        Button submitButton = Controls.button("query", event -> {
            Task<List<ActivityVO>> activityListTask = activityListTask();
            executor.execute(activityListTask);
        });
        Button addButton = Controls.button("add", event -> {
            ActivityDialog activityDialog = new ActivityDialog();
            Stage stage = new Stage();
            try {
                activityDialog.start(stage);
                stage.show();
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        });
        headerView.getChildren().addAll(startDatePicker, endDatePicker, keywordTextField, submitButton, addButton);

        return headerView;
    }

    private Task<List<ActivityVO>> activityListTask() {
        Task<List<ActivityVO>> activityListTask = new Task<List<ActivityVO>>() {
            @Override
            protected List<ActivityVO> call() throws Exception {
                activityList = activityApi.activityList(startDate, endDate, keyword.getValue());
                return activityList;
            }
        };
        activityListTask.setOnSucceeded(event -> {
            activityList = activityListTask.getValue();
            activityTableView.setItems(FXCollections.observableList(activityList));
        });
        activityListTask.setOnFailed(event -> {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText(null);
            alert.setContentText(activityListTask.getException().getMessage());
            alert.showAndWait();
        });
        return activityListTask;
    }

    private TableView<ActivityVO> activityTableView() {
        ObservableList<ActivityVO> activityObservableList = FXCollections.observableList(activityList);
        TableView<ActivityVO> activityTableView = new TableView<>(activityObservableList);
        activityTableView.getColumns().addAll(
                usernameColumn(),
                topicColumn(),
                budgetColumn(),
                numberColumn(),
                activityDateColumn());
        return activityTableView;
    }

    private TableColumn<ActivityVO, String> usernameColumn() {
        TableColumn<ActivityVO, String> usernameColumn = new TableColumn<>("Username");
        usernameColumn.setCellValueFactory(new PropertyValueFactory<>("username"));
        return usernameColumn;
    }

    private TableColumn<ActivityVO, String> topicColumn() {
        TableColumn<ActivityVO, String> topicColumn = new TableColumn<>("Topic");
        topicColumn.setCellValueFactory(new PropertyValueFactory<>("topic"));
        return topicColumn;
    }

    private TableColumn<ActivityVO, String> budgetColumn() {
        TableColumn<ActivityVO, String> budgetColumn = new TableColumn<>("Budget");
        budgetColumn.setCellValueFactory(new PropertyValueFactory<>("budget"));
        return budgetColumn;
    }

    private TableColumn<ActivityVO, Double> numberColumn() {
        TableColumn<ActivityVO, Double> numberColumn = new TableColumn<>("Number");
        numberColumn.setCellValueFactory(new PropertyValueFactory<>("number"));
        return numberColumn;
    }

    private TableColumn<ActivityVO, LocalDate> activityDateColumn() {
        TableColumn<ActivityVO, LocalDate> activityDateColumn = new TableColumn<>("ActivityDate");
        activityDateColumn.setCellValueFactory(new PropertyValueFactory<>("activityDate"));
        return activityDateColumn;
    }
}
