package com.individual.treemanagement.common;

import lombok.Getter;

public enum RoleEnum {

    Admin(1, "管理员"),
    Member(2, "会员"),
    Guest(3, "访客");

    @Getter
    private Integer code;

    @Getter
    private String name;

    RoleEnum(Integer code, String name) {
        this.code = code;
        this.name = name;
    }

    public static RoleEnum getRoleByCode(Integer code) {
        RoleEnum[] roleEnums = RoleEnum.values();
        for (RoleEnum roleEnum : roleEnums) {
            if (roleEnum.code.equals(code)) {
                return roleEnum;
            }
        }
        return null;
    }
}
