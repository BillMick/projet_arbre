package com.individual.treemanagement.common;

import com.individual.treemanagement.dto.pojo.vo.SystemUserVO;
import javafx.beans.property.Property;
import javafx.concurrent.Task;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

/**
 * @author li
 * @date create in 2025/1/18 12:29
 **/
public class Controls {

    public static DatePicker startDatePicker(EventHandler<ActionEvent> event) {
        DatePicker startDatePicker = new DatePicker();
        startDatePicker.setPromptText("Start Date");
        startDatePicker.setOnAction(event);
        return startDatePicker;
    }

    public static DatePicker endDatePicker(EventHandler<ActionEvent> event) {
        DatePicker endDatePicker = new DatePicker();
        endDatePicker.setPromptText("End Date");
        endDatePicker.setOnAction(event);
        return endDatePicker;
    }

    public static TextField keywordTextField(Property<String> bind) {
        TextField keywordTextField = new TextField();
        keywordTextField.setPromptText("Keyword");
        keywordTextField.textProperty().bindBidirectional(bind);
        return keywordTextField;
    }

    public static ComboBox<String> statusComboBox(List<String> selector, EventHandler<ActionEvent> event) {
        ComboBox<String> statusComboBox = new ComboBox<>();
        statusComboBox.getItems().setAll(selector);
        statusComboBox.setOnAction(event);
        return statusComboBox;
    }

    public static Button submitButton(EventHandler<ActionEvent> event) {
        Button submitButton = new Button("Submit");
        submitButton.setOnAction(event);
        return submitButton;
    }

    public static Button button(String name, EventHandler<ActionEvent> event) {
        Button submitButton = new Button(name);
        submitButton.setOnAction(event);
        return submitButton;
    }
}
