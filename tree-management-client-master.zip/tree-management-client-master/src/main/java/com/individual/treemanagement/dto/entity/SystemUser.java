package com.individual.treemanagement.dto.entity;

import lombok.Data;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Data
public class SystemUser implements Serializable {
	/**
	 * 用户id
	 */
	private Long userId;
	/**
	 * 用户名
	 */
	private String username;
	/**
	 * 密码
	 */
	private String password;
	/**
	 * 名字
	 */
	private String firstName;
	/**
	 * 姓
	 */
	private String lastName;
	/**
	 * 出生日期
	 */
	private LocalDate birthday;
	/**
	 * 地址
	 */
	private String address;
	/**
	 * 注册日期
	 */
	private LocalDateTime registrationTime;
	/**
	 * 更新日期
	 */
	private LocalDateTime updateTime;
	/**
	 * 状态
	 */
	private Integer status;
}
