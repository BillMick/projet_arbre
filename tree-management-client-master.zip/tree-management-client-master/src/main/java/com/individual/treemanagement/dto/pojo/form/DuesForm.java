package com.individual.treemanagement.dto.pojo.form;

import lombok.Data;

import java.io.Serializable;

/**
 * @author li
 * @date create in 2025/1/13 21:46
 **/
@Data
public class DuesForm implements Serializable {

    private Integer year;

    private Double dues;
}
