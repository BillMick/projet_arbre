package com.individual.treemanagement.dto.pojo.vo;

import lombok.Data;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * @author li
 * @date create in 2025/1/17 10:18
 **/
@Data
public class SystemVoteVO implements Serializable {
    private Long userId;

    private String username;

    private Long voteId;

    private String voteUsername;

    private LocalDateTime createTime;

    private LocalDateTime updateTime;
}
