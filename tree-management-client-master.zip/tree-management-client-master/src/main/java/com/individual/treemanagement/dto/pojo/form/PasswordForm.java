package com.individual.treemanagement.dto.pojo.form;

import lombok.Data;

import java.io.Serializable;

/**
 * @author li
 * @date create in 2025/1/13 11:21
 **/
@Data
public class PasswordForm implements Serializable {
    private String oldPassword;

    private String newPassword;
}
