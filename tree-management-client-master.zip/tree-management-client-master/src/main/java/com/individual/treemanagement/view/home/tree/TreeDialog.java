package com.individual.treemanagement.view.home.tree;

import com.individual.treemanagement.api.TreeApi;
import com.individual.treemanagement.common.Controls;
import com.individual.treemanagement.config.InitConfigurer;
import com.individual.treemanagement.dto.pojo.form.TreeForm;
import com.individual.treemanagement.dto.pojo.vo.TreeVO;
import javafx.application.Application;
import javafx.concurrent.Task;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;

import java.util.concurrent.ThreadPoolExecutor;
import java.util.function.UnaryOperator;

/**
 * @author li
 * @date create in 2025/1/18 16:22
 **/
public class TreeDialog extends Application {

    private BorderPane borderPane;
    private TreeForm treeForm;
    private TreeVO tree;
    private TreeApi treeApi;
    private ThreadPoolExecutor executor;
    private boolean isAdd;

    public TreeDialog(TreeVO tree) {
        borderPane = new BorderPane();
        treeForm = new TreeForm();
        this.tree = tree;
        treeApi = new TreeApi();
        executor = InitConfigurer.executor;
        isAdd = false;
    }

    public TreeDialog() {
        borderPane = new BorderPane();
        treeForm = new TreeForm();
        tree = new TreeVO();
        treeApi = new TreeApi();
        executor = InitConfigurer.executor;
        isAdd = true;
    }

    @Override
    public void start(Stage primaryStage) {
        VBox vbox = new VBox();
        vbox.getChildren().addAll(
                createGenusBar(tree.getGenus()),
                createSpeciesBar(tree.getSpecies()),
                createNameBar(tree.getCommonName()),
                createBustSizeBar(tree.getBustSize()),
                createHeightBar(tree.getHeight()),
                createLatitudeBar(tree.getLatitude()),
                createLongitudeBar(tree.getLongitude()),
                createDevelopmentalStageBar(tree.getDevelopmentalStage())
        );

        Button updateButton = Controls.button("Submit", event -> {
            if(isAdd) {
                executor.execute(addTreeTask());
            } else {
                executor.execute(updateTreeTask(tree.getTreeId()));
            }
            primaryStage.close();
        });

        Button cancelButton = Controls.button("Cancel", event -> {
            primaryStage.close();
        });

        HBox buttonBar = new HBox();
        buttonBar.getChildren().addAll(updateButton, cancelButton);
        vbox.getChildren().add(buttonBar);
        borderPane.setCenter(vbox);

        Scene scene = new Scene(borderPane, 500, 600);
        // 加载css文件
        scene.getStylesheets().add(getClass().getClassLoader().getResource("TreeDialog.css").toExternalForm());
        primaryStage.setTitle("Edit Tree");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private Task<Void> updateTreeTask(Long treeId) {
        Task<Void> updateTreeTask = new Task<Void>() {
            @Override
            protected Void call() throws Exception {
                treeApi.updateTree(treeId, treeForm);
                return null;
            }
        };
        updateTreeTask.setOnSucceeded(event -> {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Update Tree");
            alert.setHeaderText(null);
            alert.setContentText("Tree updated");
            alert.showAndWait();
        });
        return updateTreeTask;
    }

    private Task<Void> addTreeTask() {
        Task<Void> addTreeTask = new Task<Void>() {
            @Override
            protected Void call() throws Exception {
                treeApi.registeredTree(treeForm);
                return null;
            }
        };
        addTreeTask.setOnSucceeded(event -> {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Add Tree");
            alert.setHeaderText(null);
            alert.setContentText("Tree added");
        });
        return addTreeTask;
    }

    // 创建Genus的HBox
    private AnchorPane  createGenusBar(String genus) {
        AnchorPane genusBar = new AnchorPane();
        Label genusLabel = new Label("Genus");
        TextField genusField = new TextField();
        if(!isAdd) {
            genusField.setText(genus);
        }
        Label requiredLabel = new Label("*");
        genusField.textProperty().addListener((observable, oldValue, newValue) -> {
            treeForm.setGenus(newValue);
        });
        this.setAnchor(genusLabel, genusField, requiredLabel);
        genusBar.getChildren().addAll(genusLabel, genusField, requiredLabel);
        return genusBar;
    }

    // 创建Species的HBox
    private AnchorPane createSpeciesBar(String species) {
        AnchorPane speciesBar = new AnchorPane();
        Label speciesLabel = new Label("Species");
        TextField speciesField = new TextField();
        if(!isAdd) {
            speciesField.setText(species);
        }
        Label requiredLabel = new Label("*");
        speciesField.textProperty().addListener((observable, oldValue, newValue) -> {
            treeForm.setSpecies(newValue);
        });
        this.setAnchor(speciesLabel, speciesField, requiredLabel);
        speciesBar.getChildren().addAll(speciesLabel, speciesField, requiredLabel);
        return speciesBar;
    }

    // 创建Common Name的HBox
    private AnchorPane createNameBar(String commonName) {
        AnchorPane nameBar = new AnchorPane();
        Label nameLabel = new Label("Common Name");
        TextField nameField = new TextField();
        if(!isAdd) {
            nameField.setText(commonName);
        }
        Label requiredLabel = new Label("*");
        nameField.textProperty().addListener((observable, oldValue, newValue) -> {
            treeForm.setCommonName(newValue);
        });
        this.setAnchor(nameLabel, nameField, requiredLabel);
        nameBar.getChildren().addAll(nameLabel, nameField, requiredLabel);
        return nameBar;
    }

    // 创建Bust Size的HBox
    private AnchorPane createBustSizeBar(Double bustSize) {
        AnchorPane bustSizeBar = new AnchorPane();
        Label bustSizeLabel = new Label("Bust Size");
        TextField bustSizeField = new TextField();
        if(!isAdd) {
            bustSizeField.setText(String.valueOf(bustSize));
        }
        Label requiredLabel = new Label("*");
        bustSizeField.setTextFormatter(matchDoubleFormatter());
        bustSizeField.textProperty().addListener((observable, oldValue, newValue) -> {
            treeForm.setBustSize(Double.valueOf(newValue));
        });
        this.setAnchor(bustSizeLabel, bustSizeField, requiredLabel);
        bustSizeBar.getChildren().addAll(bustSizeLabel, bustSizeField, requiredLabel);
        return bustSizeBar;
    }

    // 创建Height的HBox
    private AnchorPane createHeightBar(Double height) {
        AnchorPane heightBar = new AnchorPane();
        Label heightLabel = new Label("Height");
        TextField heightField = new TextField();
        if(!isAdd) {
            heightField.setText(String.valueOf(height));
        }
        Label requiredLabel = new Label("*");
        heightField.setTextFormatter(matchDoubleFormatter());
        heightField.textProperty().addListener((observable, oldValue, newValue) -> {
            treeForm.setHeight(Double.valueOf(newValue));
        });
        this.setAnchor(heightLabel, heightField, requiredLabel);
        heightBar.getChildren().addAll(heightLabel, heightField, requiredLabel);
        return heightBar;
    }

    // 创建Latitude的HBox
    private AnchorPane createLatitudeBar(Double latitude) {
        AnchorPane latitudeBar = new AnchorPane();
        Label latitudeLabel = new Label("Latitude");
        TextField latitudeField = new TextField();
        if(!isAdd) {
            latitudeField.setText(String.valueOf(latitude));
        }
        Label requiredLabel = new Label("*");
        latitudeField.setTextFormatter(matchDoubleFormatter());
        latitudeField.textProperty().addListener((observable, oldValue, newValue) -> {
            treeForm.setLatitude(Double.valueOf(newValue));
        });
        this.setAnchor(latitudeLabel, latitudeField, requiredLabel);
        latitudeBar.getChildren().addAll(latitudeLabel, latitudeField, requiredLabel);
        return latitudeBar;
    }

    // 创建Longitude的HBox
    private AnchorPane createLongitudeBar(Double longitude) {
        AnchorPane longitudeBar = new AnchorPane();
        Label longitudeLabel = new Label("Longitude");
        TextField longitudeField = new TextField();
        if(!isAdd) {
            longitudeField.setText(String.valueOf(longitude));
        }
        Label requiredLabel = new Label("*");
        longitudeField.setTextFormatter(matchDoubleFormatter());
        longitudeField.textProperty().addListener((observable, oldValue, newValue) -> {
            treeForm.setLongitude(Double.valueOf(newValue));
        });
        this.setAnchor(longitudeLabel, longitudeField, requiredLabel);
        longitudeBar.getChildren().addAll(longitudeLabel, longitudeField, requiredLabel);
        return longitudeBar;
    }

    // 创建Developmental Stage的HBox
    private AnchorPane createDevelopmentalStageBar(String developmentalStage) {
        AnchorPane developmentalStageBar = new AnchorPane();
        Label developmentalStageLabel = new Label("Developmental Stage");
        TextField developmentalStageField = new TextField();
        if(!isAdd) {
            developmentalStageField.setText(developmentalStage);
        }
        Label requiredLabel = new Label("*");
        developmentalStageField.textProperty().addListener((observable, oldValue, newValue) -> {
            treeForm.setDevelopmentalStage(developmentalStage);
        });
        this.setAnchor(developmentalStageLabel, developmentalStageField, requiredLabel);
        developmentalStageBar.getChildren().addAll(developmentalStageLabel, developmentalStageField, requiredLabel);
        return developmentalStageBar;
    }

    private static TextFormatter<String> matchDoubleFormatter() {
        // 使用正则表达式限制只能输入正的浮点数
        UnaryOperator<TextFormatter.Change> filter = change -> {
            String newText = change.getControlNewText();
            if (newText.matches("^\\d*\\.?\\d*$") || newText.isEmpty()) {
                return change; // 如果是合法的浮点数则允许输入
            }
            return null; // 否则不允许输入
        };
        return new TextFormatter<>(filter);
    }

    public void setAnchor(Label title, TextField input, Label required) {
        AnchorPane.setLeftAnchor(title, 10.0);
        AnchorPane.setRightAnchor(input, 50.0);
        AnchorPane.setRightAnchor(required, 10.0);
    }
}
