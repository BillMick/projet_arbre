package com.individual.treemanagement.dto.pojo.vo;

import lombok.Builder;
import lombok.Data;

/**
 * @author li
 * @date create in 2024/6/1-23:12
 **/
@Data
public class LoginResult {

    private String accessToken;

    private Long expireTime;

    private Integer roleId;

    private Long userId;
}
