package com.individual.treemanagement.api;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.individual.treemanagement.config.InitConfigurer;
import com.individual.treemanagement.dto.entity.SystemDues;
import com.individual.treemanagement.dto.pojo.vo.SystemRoleVO;
import com.individual.treemanagement.dto.pojo.vo.SystemUserDuesVO;
import com.individual.treemanagement.dto.pojo.vo.SystemUserVO;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.individual.treemanagement.common.UrlConstants.*;

/**
 * @author li
 * @date create in 2025/1/17 21:15
 **/
public class AdminApi {

    private final ObjectMapper objectMapper;

    public AdminApi() {
        objectMapper = InitConfigurer.objectMapper;
    }

    public void enableUser(Long userId) {
        MultiValueMap<String, Object> form = new LinkedMultiValueMap<>();
        form.add("userId", userId);
        Request.postRequest(domain + enableApi, form);
    }

    public void disableUser(Long userId) {
        MultiValueMap<String, Object> form = new LinkedMultiValueMap<>();
        form.add("userId", userId);
        Request.postRequest(domain + disableApi, form);
    }

    public List<SystemDues> getDuesList(LocalDate startDate, LocalDate endDate) {
        MultiValueMap<String, Object> form = new LinkedMultiValueMap<>();
        form.add("startDate", startDate);
        form.add("endDate", endDate);
        JsonNode data = Request.postRequest(domain + duesApi, form);
        return objectMapper.convertValue(data, objectMapper.getTypeFactory().constructCollectionType(List.class, SystemDues.class));
    }

    public void finalizedTree() {
        Request.postRequest(domain + finalizedTreeApi, objectMapper.createObjectNode());
    }

    public List<SystemRoleVO> getRoleList() {
        JsonNode data = Request.postRequest(domain + roleApi, objectMapper.createObjectNode());
        return objectMapper.convertValue(data, objectMapper.getTypeFactory().constructCollectionType(List.class, SystemRoleVO.class));
    }

    public List<SystemUserVO> getUserList(LocalDate startDate, LocalDate endDate, Integer status, String keyword) {
        MultiValueMap<String, Object> form = new LinkedMultiValueMap<>();
        form.add("startDate", startDate);
        form.add("endDate", endDate);
        form.add("status", status);
        form.add("keyword", keyword);
        JsonNode data = Request.postRequest(domain + userApi, form);
        return objectMapper.convertValue(data, objectMapper.getTypeFactory().constructCollectionType(List.class, SystemUserVO.class));
    }

    public void resetPassword(Long userId) {
        MultiValueMap<String, Object> form = new LinkedMultiValueMap<>();
        form.add("userId", userId);
        Request.postRequest(domain + resetApi, form);
    }

    public void setYearDues(Double yearDues) {
        MultiValueMap<String, Object> form = new LinkedMultiValueMap<>();
        form.add("yearDues", yearDues);
        Request.postRequest(domain + yearDuesApi, form);
    }

    public List<SystemUserDuesVO> getUserDuesList(LocalDate startDate, LocalDate endDate, Integer paid) {
        Map<String, Object> form = new HashMap<>();
        form.put("startDate", startDate);
        form.put("endDate", endDate);
        form.put("paid", paid);
        JsonNode data = Request.getRequest(domain + userDuesApi, form);
        return objectMapper.convertValue(data, objectMapper.getTypeFactory().constructCollectionType(List.class, SystemUserDuesVO.class));
    }
}
