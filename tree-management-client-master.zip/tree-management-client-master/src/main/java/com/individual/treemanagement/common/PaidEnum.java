package com.individual.treemanagement.common;

import lombok.Getter;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public enum PaidEnum {

    Unpaid(0, "未支付"),
    Paid(1, "支付"),
    Donation(2, "捐赠");

    @Getter
    private Integer code;

    private String name;

    PaidEnum(Integer code, String name) {
        this.code = code;
        this.name = name;
    }

    public static List<String> paidEnumNames() {
        PaidEnum[] paidEnums = PaidEnum.values();
        return Arrays.stream(paidEnums).map(PaidEnum::name).collect(Collectors.toList());
    }
}
