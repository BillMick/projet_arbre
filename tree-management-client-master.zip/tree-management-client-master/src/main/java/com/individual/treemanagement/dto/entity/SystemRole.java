package com.individual.treemanagement.dto.entity;

import lombok.Data;

import java.io.Serializable;
import java.time.LocalDateTime;

@Data
public class SystemRole implements Serializable {
	/**
	 * 主键
	 */
	private Integer roleId;
	/**
	 * 角色名称
	 */
	private String roleName;
	/**
	 * 角色编码
	 */
	private String roleCode;
	/**
	 * 角色描述
	 */
	private String remark;
	/**
	 * 创建时间
	 */
	private LocalDateTime updateTime;
	/**
	 * 创建时间
	 */
	private LocalDateTime createTime;
}
