package com.individual.treemanagement.dto.pojo.form;

import lombok.Data;

import java.io.Serializable;
import java.time.LocalDate;

/**
 * @author li
 * @date create in 2025/1/14 14:17
 **/
@Data
public class ActivityForm implements Serializable {
    private Long treeId;

    private String topic;

    private Double budget;

    private Integer number;

    private LocalDate activityDate;
}
