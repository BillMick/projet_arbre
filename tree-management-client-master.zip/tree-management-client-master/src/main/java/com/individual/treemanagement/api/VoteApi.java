package com.individual.treemanagement.api;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.individual.treemanagement.config.InitConfigurer;
import com.individual.treemanagement.dto.pojo.vo.SystemVoteVO;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.individual.treemanagement.common.UrlConstants.*;

/**
 * @author li
 * @date create in 2025/1/17 21:53
 **/
public class VoteApi {

    private final ObjectMapper objectMapper;

    public VoteApi() {
        this.objectMapper = InitConfigurer.objectMapper;
    }

    public List<SystemVoteVO> getVoteUserList(LocalDate startDate, LocalDate endDate) {
        Map<String, Object> paramMap = new HashMap<>();
        paramMap.put("startDate", startDate);
        paramMap.put("endDate", endDate);
        JsonNode data = Request.getRequest(domain + voteListApi, paramMap);
        return objectMapper.convertValue(data, objectMapper.getTypeFactory().constructCollectionType(List.class, SystemVoteVO.class));
    }

    public void voteUser(Long voteId) {
        MultiValueMap<String, Object> form = new LinkedMultiValueMap<>();
        form.add("voteId", voteId);
        Request.postRequest(domain + voteApi, form);
    }

    public List<SystemVoteVO> getMyselfVoteList() {
        JsonNode data = Request.getRequest(domain + voteUserApi, new HashMap<>());
        return objectMapper.convertValue(data, objectMapper.getTypeFactory().constructCollectionType(List.class, SystemVoteVO.class));
    }
}
