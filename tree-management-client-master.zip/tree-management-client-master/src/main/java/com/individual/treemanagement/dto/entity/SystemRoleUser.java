package com.individual.treemanagement.dto.entity;

import lombok.Data;

import java.io.Serializable;
import java.time.LocalDateTime;

@Data
public class SystemRoleUser implements Serializable {
	/**
	 * 
	 */
	private Long id;
	/**
	 * 角色id
	 */
	private Integer roleId;
	/**
	 * 用户id
	 */
	private Long userId;
	/**
	 * 更新时间
	 */
	private LocalDateTime updateTime;
	/**
	 * 创建时间
	 */
	private LocalDateTime createTime;
}
