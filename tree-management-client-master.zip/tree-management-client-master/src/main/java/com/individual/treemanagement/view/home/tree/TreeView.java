package com.individual.treemanagement.view.home.tree;

import com.individual.treemanagement.api.Request;
import com.individual.treemanagement.api.TreeApi;
import com.individual.treemanagement.common.Controls;
import com.individual.treemanagement.common.LocalStorage;
import com.individual.treemanagement.common.RoleEnum;
import com.individual.treemanagement.common.TreeStatusEnum;
import com.individual.treemanagement.config.InitConfigurer;
import com.individual.treemanagement.dto.pojo.vo.TreeVO;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.concurrent.Task;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.util.Callback;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.concurrent.ThreadPoolExecutor;

/**
 * @author li
 * @date create in 2025/1/17 20:33
 **/
public class TreeView {
    private TableView<TreeVO> treeTableView;
    private HBox headerPane;
    private TreeApi treeApi;
    private SimpleStringProperty keyword;
    private LocalDate startDate;
    private LocalDate endDate;
    private Integer status;
    private List<TreeVO> treeList;
    private ThreadPoolExecutor executor;

    public TreeView() {
        treeApi = new TreeApi();
        keyword = new SimpleStringProperty();
        treeList = treeApi.treeList(startDate, endDate, status, keyword.getValue());
        executor = InitConfigurer.executor;
        treeTableView = treeTableView();
        headerPane = headerView();
    }

    public VBox createTreeView() {
        VBox treeView = new VBox();
        treeView.setSpacing(10.0);
        treeView.getChildren().addAll(headerPane, treeTableView);
        return treeView;
    }

    private HBox headerView() {
        HBox headerView = new HBox();
        headerView.setSpacing(5.0);
        DatePicker startDatePicker = Controls.startDatePicker(event -> {
            startDate =  ((DatePicker) event.getSource()).getValue();
        });
        DatePicker endDatePicker = Controls.endDatePicker(event -> {
            endDate =  ((DatePicker) event.getSource()).getValue();
        });
        TextField keywordTextField = Controls.keywordTextField(keyword);
        ComboBox<String> statusComboBox = Controls.statusComboBox(TreeStatusEnum.treeStatusEnumNames(), event -> {
            String selectedItem = ((ComboBox<String>) event.getSource()).getSelectionModel().getSelectedItem();
            Integer treeStatus = TreeStatusEnum.valueOf(selectedItem).getStatus();
            status = treeStatus;
        });
        Button submitButton = Controls.button("query", event -> {
            Task<List<TreeVO>> treeListTask = treeListTask();
            executor.execute(treeListTask);
        });
        Button addButton = Controls.button("add", event -> {
            TreeDialog treeDialog = new TreeDialog();
            Stage stage = new Stage();
            try {
                treeDialog.start(stage);
                stage.show();
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        });
        headerView.getChildren().addAll(startDatePicker, endDatePicker, keywordTextField, statusComboBox, submitButton, addButton);

        return headerView;
    }

    private Task<List<TreeVO>> treeListTask() {
        Task<List<TreeVO>> treeListTask = new Task<List<TreeVO>>() {
            @Override
            protected List<TreeVO> call() throws Exception {
                treeList = treeApi.treeList(startDate, endDate, status, keyword.getValue());
                return treeList;
            }
        };
        treeListTask.setOnSucceeded(event -> {
            treeList = treeListTask.getValue();
            treeTableView.setItems(FXCollections.observableList(treeList));
        });
        return treeListTask;
    }

    private TableView<TreeVO> treeTableView() {
        ObservableList<TreeVO> treeObservableList = FXCollections.observableList(treeList);
        TableView<TreeVO> treeTableView = new TableView<>(treeObservableList);
        treeTableView.getColumns().addAll(
                genusColumn(),
                speciesColumn(),
                nameColumn(),
                bustSizeColumn(),
                heightColumn(),
                developmentalStageColumn(),
                longitudeColumn(),
                latitudeColumn(),
                statusColumn(),
                createTimeColumn(),
                updateTimeColumn(),
                operationColumn());
        return treeTableView;
    }

    private TableColumn<TreeVO, String> genusColumn() {
        TableColumn<TreeVO, String> genusColumn = new TableColumn<>("Genus");
        genusColumn.setCellValueFactory(new PropertyValueFactory<>("genus"));
        return genusColumn;
    }

    private TableColumn<TreeVO, String> speciesColumn() {
        TableColumn<TreeVO, String> speciesColumn = new TableColumn<>("Species");
        speciesColumn.setCellValueFactory(new PropertyValueFactory<>("species"));
        return speciesColumn;
    }

    private TableColumn<TreeVO, String> nameColumn() {
        TableColumn<TreeVO, String> nameColumn = new TableColumn<>("CommonName");
        nameColumn.setCellValueFactory(new PropertyValueFactory<>("commonName"));
        return nameColumn;
    }

    private TableColumn<TreeVO, Double> bustSizeColumn() {
        TableColumn<TreeVO, Double> bustSizeColumn = new TableColumn<>("Bust Size");
        bustSizeColumn.setCellValueFactory(new PropertyValueFactory<>("bustSize"));
        return bustSizeColumn;
    }

    private TableColumn<TreeVO, Double> heightColumn() {
        TableColumn<TreeVO, Double> heightColumn = new TableColumn<>("Height");
        heightColumn.setCellValueFactory(new PropertyValueFactory<>("height"));
        return heightColumn;
    }

    private TableColumn<TreeVO, String> developmentalStageColumn() {
        TableColumn<TreeVO, String> developmentalStageColumn = new TableColumn<>("Developmental Stage");
        developmentalStageColumn.setCellValueFactory(new PropertyValueFactory<>("developmentalStage"));
        return developmentalStageColumn;
    }

    private TableColumn<TreeVO, Double> longitudeColumn() {
        TableColumn<TreeVO, Double> longitudeColumn = new TableColumn<>("Longitude");
        longitudeColumn.setCellValueFactory(new PropertyValueFactory<>("longitude"));
        return longitudeColumn;
    }

    private TableColumn<TreeVO, Double> latitudeColumn() {
        TableColumn<TreeVO, Double> latitudeColumn = new TableColumn<>("Latitude");
        latitudeColumn.setCellValueFactory(new PropertyValueFactory<>("latitude"));
        return latitudeColumn;
    }

    private TableColumn<TreeVO, String> statusColumn() {
        TableColumn<TreeVO, String> statusColumn = new TableColumn<>("Status");
        statusColumn.setCellValueFactory(cellData->{
            Integer status = cellData.getValue().getStatus();
            TreeStatusEnum statusEnum = TreeStatusEnum.getTreeStatusEnum(status);
            return new SimpleStringProperty(statusEnum.getName());
        });
        return statusColumn;
    }

    private TableColumn<TreeVO, LocalDateTime> createTimeColumn() {
        TableColumn<TreeVO, LocalDateTime> createTimeColumn = new TableColumn<>("Create Time");
        createTimeColumn.setCellValueFactory(new PropertyValueFactory<>("createTime"));
        return createTimeColumn;
    }

    private TableColumn<TreeVO, LocalDateTime> updateTimeColumn() {
        TableColumn<TreeVO, LocalDateTime> updateTimeColumn = new TableColumn<>("Update Time");
        updateTimeColumn.setCellValueFactory(new PropertyValueFactory<>("updateTime"));
        return updateTimeColumn;
    }

    private TableColumn<TreeVO, String> operationColumn() {
        TableColumn<TreeVO, String> operationColumn = new TableColumn<>("Operation");
        operationColumn.setCellFactory(new Callback<TableColumn<TreeVO, String>, TableCell<TreeVO, String>>() {
            @Override
            public TableCell<TreeVO, String> call(TableColumn<TreeVO, String> param) {
                return new TableCell<TreeVO, String>() {
                    @Override
                    public void updateItem(String item, boolean empty) {
                        super.updateItem(item, empty);
                        if(empty) {
                            setGraphic(null);
                        } else {
                            HBox hBox = new HBox();
                            hBox.setSpacing(5);
                            setGraphic(hBox);
                            TreeVO tree = getTableView().getItems().get(getIndex());
                            Long treeId = tree.getTreeId();
                            if(!LocalStorage.role.equals(RoleEnum.Guest)) {
                                hBox.getChildren().addAll(updateTreeButton(tree), maintenanceTreeButton(treeId), nominateTreeButton(treeId));
                            }
                        }
                    }
                };
            }
        });
        return operationColumn;
    }

    private Button updateTreeButton(TreeVO tree) {
        Button updateTreeButton = new Button("Edit Tree");
        updateTreeButton.setOnAction(event -> {
            TreeDialog treeDialog = new TreeDialog(tree);
            Stage stage = new Stage();
            try {
                treeDialog.start(stage);
                stage.show();
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        });
        return updateTreeButton;
    }

    private Button maintenanceTreeButton(Long treeId) {
        Button maintenanceTreeButton = new Button("Maintenance Tree");
        maintenanceTreeButton.setOnAction(event -> {
           executor.execute(maintenanceTreeTask(treeId));
        });
        return maintenanceTreeButton;
    }

    private Button nominateTreeButton(Long treeId) {
        Button nominateTreeButton = new Button("Nominate Tree");
        nominateTreeButton.setOnAction(event -> {
            executor.execute(nominateTreeTask(treeId));
        });
        return nominateTreeButton;
    }

    private Task<Void> maintenanceTreeTask(Long treeId) {
        Task<Void> maintenanceTreeTask = new Task<Void>() {
            @Override
            protected Void call() throws Exception {
                treeApi.submitMaintenanceTree(treeId);
                return null;
            }
        };
        maintenanceTreeTask.setOnSucceeded(event -> {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Maintenance Tree");
            alert.setHeaderText(null);
            alert.setContentText("Submit Maintenance Tree Successfully");
            alert.showAndWait();
        });
        return maintenanceTreeTask;
    }

    private Task<Void> nominateTreeTask(Long treeId) {
        Task<Void> nominateTreeTask = new Task<Void>() {
            @Override
            protected Void call() throws Exception {
                treeApi.nominateTree(treeId);
                return null;
            }
        };
        nominateTreeTask.setOnSucceeded(event -> {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Nominate Tree");
            alert.setHeaderText(null);
            alert.setContentText("Submit Nominate Tree Successfully");
            alert.showAndWait();
        });
        return nominateTreeTask;
    }
}
