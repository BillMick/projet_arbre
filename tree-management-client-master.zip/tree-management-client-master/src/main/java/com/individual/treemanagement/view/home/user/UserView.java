package com.individual.treemanagement.view.home.user;

import com.individual.treemanagement.api.AdminApi;
import com.individual.treemanagement.api.Request;
import com.individual.treemanagement.api.VoteApi;
import com.individual.treemanagement.common.LocalStorage;
import com.individual.treemanagement.common.RoleEnum;
import com.individual.treemanagement.common.StatusEnum;
import com.individual.treemanagement.config.InitConfigurer;
import com.individual.treemanagement.dto.pojo.vo.SystemUserVO;
import com.individual.treemanagement.dto.pojo.vo.SystemVoteVO;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.concurrent.Task;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.util.Callback;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.stream.Collectors;

/**
 * @author li
 * @date create in 2025/1/17 20:33
 **/
public class UserView {

    private LocalDate startDate;
    private LocalDate endDate;
    private Integer status;
    private List<SystemUserVO> systemUserList;
    private AdminApi adminApi;
    private TableView<SystemUserVO> userTableView;
    private ThreadPoolExecutor executor;
    private SimpleStringProperty keyword;
    private VoteApi voteApi;
    private List<SystemVoteVO> systemVoteList;

    public UserView() {
        voteApi = new VoteApi();
        adminApi = new AdminApi();
        keyword = new SimpleStringProperty();
        systemUserList = adminApi.getUserList(startDate, endDate, status, keyword.getValue());
        userTableView = systemUserTableView();
        executor = InitConfigurer.executor;
        systemVoteList = voteApi.getMyselfVoteList();
    }

    public VBox creatUserView() {
        VBox userView = new VBox();
        userView.setSpacing(10.0);
        userView.getChildren().add(headControl());
        userView.getChildren().add(userTableView);
        return userView;
    }

     HBox headControl() {
        HBox headControl = new HBox();
        headControl.setSpacing(5.0);
        headControl.getChildren().addAll(startDatePicker(), endDatePicker(), keywordTextField(), statusComboBox(), submitButton());
        return headControl;
    }

     DatePicker startDatePicker() {
        DatePicker startDatePicker = new DatePicker();
        startDatePicker.setPromptText("Start Date");
        startDatePicker.setOnAction(event -> {
            startDate = startDatePicker.getValue();
        });
        return startDatePicker;
    }

     DatePicker endDatePicker() {
        DatePicker endDatePicker = new DatePicker();
        endDatePicker.setPromptText("End Date");
        endDatePicker.setOnAction(event -> {
            endDate = endDatePicker.getValue();
        });
        return endDatePicker;
    }

     TextField keywordTextField() {
        TextField keywordTextField = new TextField();
        keywordTextField.setPromptText("Keyword");
        keywordTextField.textProperty().bindBidirectional(keyword);
        return keywordTextField;
    }

     ComboBox<String> statusComboBox() {
        ComboBox<String> statusComboBox = new ComboBox<>();
        List<String> statusList = Arrays.stream(StatusEnum.values()).map(Enum::name).collect(Collectors.toList());
        statusComboBox.getItems().setAll(statusList);
        statusComboBox.setOnAction(event -> {
            String selectedStatus = statusComboBox.getSelectionModel().getSelectedItem();
            StatusEnum statusEnum = StatusEnum.valueOf(selectedStatus);
            status = statusEnum.getStatus();
        });
        return statusComboBox;
    }

     Button submitButton() {
        Button submitButton = new Button("Submit");
        submitButton.setOnAction(event -> {
            Task<List<SystemUserVO>> userListTask = userListTask();
            CompletableFuture.runAsync(userListTask);
        });
        return submitButton;
    }


     TableView<SystemUserVO> systemUserTableView() {
        ObservableList<SystemUserVO> userObservableList = FXCollections.observableList(systemUserList);
        TableView<SystemUserVO> userTableView = new TableView<>(userObservableList);
        TableColumn<SystemUserVO, String> usernameColumn = new TableColumn<>("username");
        usernameColumn.setCellValueFactory(new PropertyValueFactory<>("username"));
        userTableView.getColumns().add(usernameColumn);

        TableColumn<SystemUserVO, String> firstNameColumn = new TableColumn<>("firstName");
        firstNameColumn.setCellValueFactory(new PropertyValueFactory<>("firstName"));
        userTableView.getColumns().add(firstNameColumn);

        TableColumn<SystemUserVO, String> lastNameColumn = new TableColumn<>("lastName");
        lastNameColumn.setCellValueFactory(new PropertyValueFactory<>("lastName"));
        userTableView.getColumns().add(lastNameColumn);

        TableColumn<SystemUserVO, LocalDate> birthdayColumn = new TableColumn<>("birthday");
        birthdayColumn.setCellValueFactory(new PropertyValueFactory<>("birthday"));
        userTableView.getColumns().add(birthdayColumn);

        TableColumn<SystemUserVO, String> addressColumn = new TableColumn<>("address");
        addressColumn.setCellValueFactory(new PropertyValueFactory<>("address"));
        userTableView.getColumns().add(addressColumn);

        TableColumn<SystemUserVO, String> statusColumn = new TableColumn<>("status");
        statusColumn.setCellValueFactory(cellData->{
            Integer status = cellData.getValue().getStatus();
            StatusEnum statusEnum = StatusEnum.getStatusEnum(status);
            return new SimpleStringProperty(statusEnum.getName());
        });
        userTableView.getColumns().add(statusColumn);

        TableColumn<SystemUserVO, String> roleColumn = new TableColumn<>("role");
        roleColumn.setCellValueFactory(cellData->{
            Integer roleId = cellData.getValue().getRoleId();
            RoleEnum role = RoleEnum.getRoleByCode(roleId);
            return new SimpleStringProperty(role.getName());
        });
        userTableView.getColumns().add(roleColumn);

        TableColumn<SystemUserVO, LocalDateTime> registrationTime = new TableColumn<>("registrationTime");
        registrationTime.setCellValueFactory(new PropertyValueFactory<>("registrationTime"));
        userTableView.getColumns().add(registrationTime);

        TableColumn<SystemUserVO, LocalDateTime> updateTime = new TableColumn<>("updateTime");
        updateTime.setCellValueFactory(new PropertyValueFactory<>("updateTime"));
        userTableView.getColumns().add(updateTime);

        userTableView.getColumns().add(operationColumn());
        return userTableView;
    }


     TableColumn<SystemUserVO, String> operationColumn() {
        TableColumn<SystemUserVO, String> operationColumn = new TableColumn<>("operation");
        operationColumn.setCellFactory(new Callback<TableColumn<SystemUserVO, String>, TableCell<SystemUserVO, String>>() {
            @Override
            public TableCell<SystemUserVO, String> call(TableColumn<SystemUserVO, String> param) {
                return new TableCell<SystemUserVO, String>() {
                    @Override
                    public void updateItem(String item, boolean empty) {
                        super.updateItem(item, empty);
                        if(empty) {
                            setGraphic(null);
                        } else {
                            HBox hBox = new HBox();
                            hBox.setSpacing(5.0);
                            setGraphic(hBox);
                            SystemUserVO systemUserVO = getTableView().getItems().get(getIndex());
                            Integer roleId = systemUserVO.getRoleId();
                            Integer status = systemUserVO.getStatus();
                            Long userId = systemUserVO.getUserId();
                            if(LocalStorage.role.equals(RoleEnum.Admin)) {
                                hBox.getChildren().add(editButton(userId));
                                // todo 封禁解禁逻辑需要考虑Guest角色
                                if(status.equals(StatusEnum.Normal.getStatus())) {
                                    hBox.getChildren().add(disableButton(userId));
                                } else if(status.equals(StatusEnum.Disable.getStatus())) {
                                    hBox.getChildren().add(enableButton(userId));
                                }
                            }
                            if(!RoleEnum.getRoleByCode(roleId).equals(RoleEnum.Guest)) {
                                hBox.getChildren().add(voteButton(userId));
                            }
                        }
                    }
                };
            }
        });
        return operationColumn;
    }

     Button enableButton(Long userId) {
        Button enableButton = new Button("Enable");
        enableButton.setOnAction(event -> {
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Enable System User");
            alert.setHeaderText(null);
            alert.setContentText("Are you sure you want to enable system user " + userId + "?");
            ButtonType result = alert.showAndWait().orElse(ButtonType.CANCEL);
            if(result == ButtonType.OK) {
                executor.execute(enableTask(userId));
            }
        });
        return enableButton;
    }

     Button disableButton(Long userId) {
        Button enableButton = new Button("Disable");
        enableButton.setOnAction(event -> {
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Disable System User");
            alert.setHeaderText(null);
            alert.setContentText("Are you sure you want to disable system user " + userId + "?");
            ButtonType result = alert.showAndWait().orElse(ButtonType.CANCEL);
            if(result == ButtonType.OK) {
                executor.execute(disableTask(userId));
            }
        });
        return enableButton;
    }

     Button editButton(Long userId) {
        Button editButton = new Button("Edit");
        editButton.setOnAction(event -> {
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Reset System User Password");
            alert.setHeaderText(null);
            alert.setContentText("Are you sure you want to disable system user " + userId + "?");
            ButtonType result = alert.showAndWait().orElse(ButtonType.CANCEL);
            if(result == ButtonType.OK) {
                executor.execute(editTask(userId));
            }
        });
        return editButton;
    }

    Button voteButton(Long userId) {
        boolean find = systemVoteList.stream().anyMatch(systemVoteVO -> systemVoteVO.getVoteId().equals(userId));
        if(find) {
            Button voteButton = new Button("Already Vote");
            voteButton.disabledProperty();
            return voteButton;
        }
        Button voteButton = new Button("Vote");
        voteButton.setOnAction(event -> {
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Vote System User");
            alert.setHeaderText(null);
            alert.setContentText("Are you sure you want to vote system user " + userId + "?");
            ButtonType result = alert.showAndWait().orElse(ButtonType.CANCEL);
            if(result == ButtonType.OK) {
                voteApi.voteUser(userId);
            }
        });
        return voteButton;
    }

     Task<List<SystemUserVO>> userListTask() {
        Task<List<SystemUserVO>> userListTask = new Task<List<SystemUserVO>>() {
            @Override
            protected List<SystemUserVO> call() throws Exception {
                systemUserList = adminApi.getUserList(startDate, endDate, status, keyword.get());
                return systemUserList;
            }
        };
        userListTask.setOnSucceeded(event -> {
            systemUserList = userListTask.getValue();
            userTableView.getItems().clear();
            userTableView.getItems().addAll(systemUserList);
        });
        return userListTask;
    }

     Task<Void> enableTask(Long userId) {
        Task<Void> enableTask = new Task<Void>() {
            @Override
            protected Void call() throws Exception {
                adminApi.enableUser(userId);
                return null;
            }
        };
        enableTask.setOnSucceeded(event -> {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Enable System User");
            alert.setHeaderText(null);
            alert.setContentText("System User Enabled Successfully");
            alert.showAndWait();
            executor.execute(userListTask());
        });
        return enableTask;
    }

     Task<Void> disableTask(Long userId) {
        Task<Void> disableTask = new Task<Void>() {
            @Override
            protected Void call() throws Exception {
                adminApi.disableUser(userId);
                return null;
            }
        };
        disableTask.setOnSucceeded(event -> {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Disable System User");
            alert.setHeaderText(null);
            alert.setContentText("System User Disable Successfully");
            executor.execute(userListTask());
        });
        return disableTask;
    }

     Task<Void> editTask(Long userId) {
        Task<Void> editTask = new Task<Void>() {
            @Override
            protected Void call() throws Exception {
                adminApi.resetPassword(userId);
                return null;
            }
        };
        editTask.setOnSucceeded(event -> {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Reset System User Password");
            alert.setHeaderText(null);
            alert.setContentText("System User Password Reset Successfully");

        });
        return editTask;
    }

}
