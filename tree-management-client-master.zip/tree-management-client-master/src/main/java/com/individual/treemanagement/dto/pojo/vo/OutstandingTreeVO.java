package com.individual.treemanagement.dto.pojo.vo;

import lombok.Data;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * @author li
 * @date create in 2025/1/14 15:21
 **/
@Data
public class OutstandingTreeVO implements Serializable {
    private Long treeId;
    /**
     * 属
     */
    private String genus;
    /**
     * 种
     */
    private String species;
    /**
     * 常用名
     */
    private String commonName;
    /**
     * 胸围
     */
    private Double bustSize;
    /**
     * 高度
     */
    private Double height;
    /**
     * 发育阶段
     */
    private String developmentalStage;
    /**
     * 经度
     */
    private Double longitude;
    /**
     * 纬度
     */
    private Double latitude;
    /**
     * 创建时间
     */
    private LocalDateTime createTime;
}
