package com.individual.treemanagement.view.home.vote;

import com.individual.treemanagement.api.UserApi;
import com.individual.treemanagement.api.VoteApi;
import com.individual.treemanagement.common.Controls;
import com.individual.treemanagement.config.InitConfigurer;
import com.individual.treemanagement.dto.pojo.vo.SystemVoteVO;
import com.individual.treemanagement.view.home.tree.TreeDialog;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.concurrent.Task;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.concurrent.ThreadPoolExecutor;

/**
 * @author li
 * @date create in 2025/1/17 20:33
 **/
public class VoteView {

    private UserApi userApi;
    private ThreadPoolExecutor executor;
    private TableView<SystemVoteVO> userVoteTableView;
    private List<SystemVoteVO> systemVoteList;
    private LocalDate startDate;
    private LocalDate endDate;
    private VoteApi voteApi;
    private HBox headerPane;

    public VoteView() {
        userApi = new UserApi();
        voteApi = new VoteApi();
        executor = InitConfigurer.executor;
        systemVoteList = voteApi.getVoteUserList(startDate, endDate);
        userVoteTableView = userVoteTableView();
        headerPane = headerView();
    }

    public VBox createTreeView() {
        VBox treeView = new VBox();
        treeView.setSpacing(10.0);
        treeView.getChildren().addAll(headerPane, userVoteTableView);
        return treeView;
    }

    private HBox headerView() {
        HBox headerView = new HBox();
        headerView.setSpacing(5.0);
        DatePicker startDatePicker = Controls.startDatePicker(event -> {
            startDate =  ((DatePicker) event.getSource()).getValue();
        });
        DatePicker endDatePicker = Controls.endDatePicker(event -> {
            endDate =  ((DatePicker) event.getSource()).getValue();
        });
        Button submitButton = Controls.button("query", event -> {
            Task<List<SystemVoteVO>> voteUserListTask = voteUserListTask();
            executor.execute(voteUserListTask);
        });
        Button addButton = Controls.button("add", event -> {
            TreeDialog treeDialog = new TreeDialog();
            Stage stage = new Stage();
            try {
                treeDialog.start(stage);
                stage.show();
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        });
        headerView.getChildren().addAll(startDatePicker, endDatePicker, submitButton, addButton);

        return headerView;
    }

    private Task<List<SystemVoteVO>> voteUserListTask() {
        Task<List<SystemVoteVO>> voteUserListTask = new Task<List<SystemVoteVO>>() {
            @Override
            protected List<SystemVoteVO> call() throws Exception {
                systemVoteList = voteApi.getVoteUserList(startDate, endDate);
                return systemVoteList;
            }
        };
        voteUserListTask.setOnSucceeded(event -> {
            systemVoteList = voteUserListTask.getValue();
            userVoteTableView.setItems(FXCollections.observableList(systemVoteList));
        });
        return voteUserListTask;
    }


    private TableView<SystemVoteVO> userVoteTableView() {
        ObservableList<SystemVoteVO> treeObservableList = FXCollections.observableList(systemVoteList);
        TableView<SystemVoteVO> voteUserTableView = new TableView<>(treeObservableList);
        voteUserTableView.getColumns().addAll(
                usernameColumn(),
                voteUsernameColumn(),
                createTimeColumn(),
                updateTimeColumn());
        return voteUserTableView;
    }

    private TableColumn<SystemVoteVO, String> usernameColumn() {
        TableColumn<SystemVoteVO, String> usernameColumn = new TableColumn<>("Username");
        usernameColumn.setCellValueFactory(new PropertyValueFactory<>("username"));
        return usernameColumn;
    }

    private TableColumn<SystemVoteVO, String> voteUsernameColumn() {
        TableColumn<SystemVoteVO, String> voteUsernameColumn = new TableColumn<>("VoteUsername");
        voteUsernameColumn.setCellValueFactory(new PropertyValueFactory<>("voteUsername"));
        return voteUsernameColumn;
    }

    private TableColumn<SystemVoteVO, LocalDateTime> createTimeColumn() {
        TableColumn<SystemVoteVO, LocalDateTime> createTimeColumn = new TableColumn<>("Create Time");
        createTimeColumn.setCellValueFactory(new PropertyValueFactory<>("createTime"));
        return createTimeColumn;
    }

    private TableColumn<SystemVoteVO, LocalDateTime> updateTimeColumn() {
        TableColumn<SystemVoteVO, LocalDateTime> updateTimeColumn = new TableColumn<>("Update Time");
        updateTimeColumn.setCellValueFactory(new PropertyValueFactory<>("updateTime"));
        return updateTimeColumn;
    }

}
