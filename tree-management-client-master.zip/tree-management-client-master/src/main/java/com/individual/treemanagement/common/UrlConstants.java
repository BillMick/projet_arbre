package com.individual.treemanagement.common;

/**
 * @author li
 * @date create in 2025/1/17 17:05
 **/
public class UrlConstants {
    public static final String domain = "http://127.0.0.1:8090";

    // 用户操作接口
    public static final String loginApi = "/api/system/login";
    public static final String registerApi = "/api/system/register";
    public static final String becomeMemberApi = "/api/system/become-membership";
    public static final String logoutApi = "/api/system/logout";
    public static final String renewalApi = "/api/system/renewal-membership";
    public static final String changePasswordApi = "/api/system/change-password";

    // 管理员操作接口
    public static final String disableApi = "/api/system/admin/disable";
    public static final String enableApi = "/api/system/admin/enable";
    public static final String duesApi = "/api/system/admin/dues-list";
    public static final String finalizedTreeApi = "/api/system/admin/finalized-outstanding-tree";
    public static final String roleApi = "/api/system/admin/role-list";
    public static final String userApi = "/api/system/admin/user-list";
    public static final String resetApi = "/api/system/admin/reset-password";
    public static final String yearDuesApi = "/api/system/admin/set-yearDues";
    public static final String userDuesApi = "/api/system/admin/user-dues-list";

    // 会费接口
    public static final String donateApi = "/api/system/donate";
    public static final String yearDonateApi = "/api/system/year-dues";

    // 投票接口
    public static final String voteListApi = "/api/system/vote-list";
    public static final String voteApi = "/api/system/vote";
    public static final String voteUserApi = "/api/system/vote-list-self";

    // 杰出树木接口
    public static final String outstandingTreeApi = "/api/outstanding-tree/list";

    // 树木接口
    public static final String treeListApi = "/api/tree/list";

    // 树木操作接口
    public static final String submitMaintenanceTreeApi = "/api/tree-operation/maintenance";
    public static final String nominateTreeApi = "/api/tree-operation/nominate";
    public static final String registeredTreeApi = "/api/tree-operation/registered";
    public static final String updateTreeApi = "/api/tree-operation/update";

    // 活动接口
    public static final String organizeActivityApi = "/api/activity/organize";
    public static final String activityListApi = "/api/activity/list";

}
