package com.individual.treemanagement.view.home.activity;

import com.individual.treemanagement.api.ActivityApi;
import com.individual.treemanagement.api.TreeApi;
import com.individual.treemanagement.common.Controls;
import com.individual.treemanagement.config.InitConfigurer;
import com.individual.treemanagement.dto.pojo.form.ActivityForm;
import com.individual.treemanagement.dto.pojo.vo.OutstandingTreeVO;
import com.individual.treemanagement.dto.pojo.vo.TreeVO;
import javafx.application.Application;
import javafx.concurrent.Task;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.util.List;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.function.UnaryOperator;
import java.util.stream.Collectors;

/**
 * @author li
 * @date create in 2025/1/18 18:30
 **/
public class ActivityDialog extends Application {

    private BorderPane borderPane;
    private ActivityForm activityForm;
    private ActivityApi activityApi;
    private ThreadPoolExecutor executor;
    private TreeApi treeApi;
    private List<OutstandingTreeVO> treeList;

    public ActivityDialog() {
        borderPane = new BorderPane();
        activityForm = new ActivityForm();
        activityApi = new ActivityApi();
        treeApi = new TreeApi();
        executor = InitConfigurer.executor;
        treeList = treeApi.outstandingTreeList(null, null, null);
    }

    @Override
    public void start(Stage primaryStage) throws Exception {
        VBox vbox = new VBox();
        vbox.getChildren().addAll(
                createTreeBar(),
                createTopicBar(),
                createNumberBar(),
                createBudgetBar(),
                createActivityDateBar());

        Button updateButton = Controls.button("Submit", event -> {
            executor.execute(addActivityTask());
            primaryStage.close();
        });

        Button cancelButton = Controls.button("Cancel", event -> {
            primaryStage.close();
        });

        HBox buttonBar = new HBox();
        buttonBar.getChildren().addAll(updateButton, cancelButton);
        vbox.getChildren().add(buttonBar);
        borderPane.setCenter(vbox);

        Scene scene = new Scene(borderPane, 500, 600);
        // 加载css文件
        scene.getStylesheets().add(getClass().getClassLoader().getResource("TreeDialog.css").toExternalForm());
        primaryStage.setTitle("Edit Tree");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private Task<Void> addActivityTask() {
        Task<Void> activityTask = new Task<Void>() {
            @Override
            protected Void call() throws Exception {
                activityApi.organizeActivity(activityForm);
                return null;
            }
        };
        return activityTask;
    }

    private AnchorPane createTreeBar() {
        AnchorPane treeBar = new AnchorPane();
        Label treeLabel = new Label("Tree");
        List<String> treeNames = treeList.stream().map(OutstandingTreeVO::getCommonName).collect(Collectors.toList());
        ComboBox<String> treeComboBox = Controls.statusComboBox(treeNames, event -> {
            String selectedItem = ((ComboBox<String>) event.getSource()).getSelectionModel().getSelectedItem();
            OutstandingTreeVO selectTree = treeList.stream().filter(tree -> tree.getCommonName().equals(selectedItem)).findFirst().get();
            activityForm.setTreeId(selectTree.getTreeId());
        });
        Label requiredLabel = new Label("*");
        this.setAnchor(treeLabel, treeComboBox, requiredLabel);
        treeBar.getChildren().addAll(treeLabel, treeComboBox, requiredLabel);
        return treeBar;
    }

    private AnchorPane createTopicBar() {
        AnchorPane topicBar = new AnchorPane();
        Label topicLabel = new Label("Topic");
        TextField topicField = new TextField();
        Label requiredLabel = new Label("*");
        topicField.textProperty().addListener((observable, oldValue, newValue) -> {
            activityForm.setTopic(newValue);
        });
        this.setAnchor(topicLabel, topicField, requiredLabel);
        topicBar.getChildren().addAll(topicLabel, topicField, requiredLabel);
        return topicBar;
    }

    private AnchorPane createBudgetBar() {
        AnchorPane budgetBar = new AnchorPane();
        Label budgetLabel = new Label("Budget");
        TextField budgetField = new TextField();
        Label requiredLabel = new Label("*");
        budgetField.setTextFormatter(matchDoubleFormatter());
        budgetField.textProperty().addListener((observable, oldValue, newValue) -> {
            activityForm.setBudget(Double.valueOf(newValue));
        });
        this.setAnchor(budgetLabel, budgetField, requiredLabel);
        budgetBar.getChildren().addAll(budgetLabel, budgetField, requiredLabel);
        return budgetBar;
    }

    private AnchorPane createNumberBar() {
        AnchorPane numberBar = new AnchorPane();
        Label numberLabel = new Label("Number");
        TextField numberField = new TextField();
        numberField.setTextFormatter(matchNumberFormatter());
        Label requiredLabel = new Label("*");
        numberField.textProperty().addListener((observable, oldValue, newValue) -> {
            activityForm.setNumber(Integer.valueOf(newValue));
        });
        this.setAnchor(numberLabel, numberField, requiredLabel);
        numberBar.getChildren().addAll(numberLabel, numberField, requiredLabel);
        return numberBar;
    }

    private AnchorPane createActivityDateBar() {
        AnchorPane activityDateBar = new AnchorPane();
        Label activityDateLabel = new Label("Activity Date");
        DatePicker activityDatePicker = new DatePicker();
        activityDateLabel.setLabelFor(activityDatePicker);
        activityDatePicker.setOnAction(event -> {
            activityForm.setActivityDate(activityDatePicker.getValue());
        });
        Label requiredLabel = new Label("*");
        this.setAnchor(activityDateLabel, activityDatePicker, requiredLabel);
        activityDateBar.getChildren().addAll(activityDateLabel, activityDatePicker, requiredLabel);
        return activityDateBar;
    }



    public void setAnchor(Node title, Node input, Node required) {
        AnchorPane.setLeftAnchor(title, 10.0);
        AnchorPane.setRightAnchor(input, 50.0);
        AnchorPane.setRightAnchor(required, 10.0);
    }

    private static TextFormatter<String> matchNumberFormatter() {
        // 使用正则表达式限制只能输入正的浮点数
        UnaryOperator<TextFormatter.Change> filter = change -> {
            String newText = change.getControlNewText();
            if (newText.matches("[0-9]*") || newText.isEmpty()) {
                return change; // 如果是合法的浮点数则允许输入
            }
            return null; // 否则不允许输入
        };
        return new TextFormatter<>(filter);
    }

    private static TextFormatter<String> matchDoubleFormatter() {
        // 使用正则表达式限制只能输入正的浮点数
        UnaryOperator<TextFormatter.Change> filter = change -> {
            String newText = change.getControlNewText();
            if (newText.matches("^\\d*\\.?\\d*$") || newText.isEmpty()) {
                return change; // 如果是合法的浮点数则允许输入
            }
            return null; // 否则不允许输入
        };
        return new TextFormatter<>(filter);
    }
}
