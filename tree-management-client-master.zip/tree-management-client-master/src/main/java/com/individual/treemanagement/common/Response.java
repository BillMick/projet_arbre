package com.individual.treemanagement.common;

import lombok.Data;

import java.io.Serializable;

/**
 * @author li
 * @date create in 2024/5/31-21:06
 **/
@Data
public class Response<T> implements Serializable {
    private static final long serialVersionUID = 1L;

    private Integer code;

    private String message;

    private T data;

    public Response() {
        super();
    }

    public Response(Integer code, String message) {
        this.code = code;
        this.message = message;
    }

    public Response(Integer code, String message, T data) {
        this.code = code;
        this.message = message;
        this.data = data;
    }
}