package com.individual.treemanagement.dto.pojo.form;

import lombok.Data;

import java.io.Serializable;

/**
 * @author li
 * @date create in 2025/1/13 11:13
 **/
@Data
public class LoginForm implements Serializable {
    private String username;

    private String password;
}
