package com.individual.treemanagement.dto.pojo.vo;

import lombok.Data;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * @author li
 * @date create in 2025/1/14 9:16
 **/
@Data
public class SystemUserVO implements Serializable {
    /**
     * 用户id
     */
    private Long userId;
    /**
     * 用户名
     */
    private String username;
    /**
     * 名字
     */
    private String firstName;
    /**
     * 姓
     */
    private String lastName;
    /**
     * 出生日期
     */
    private LocalDate birthday;
    /**
     * 地址
     */
    private String address;
    /**
     * 注册日期
     */
    private LocalDateTime registrationTime;
    /**
     * 更新日期
     */
    private LocalDateTime updateTime;
    /**
     * 状态
     */
    private Integer status;

    private Integer roleId;

    private String roleName;
}
