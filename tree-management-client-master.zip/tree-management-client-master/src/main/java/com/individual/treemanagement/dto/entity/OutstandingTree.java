package com.individual.treemanagement.dto.entity;

import lombok.Data;

import java.time.LocalDateTime;

/**
 * @author li
 * @date create in 2025/1/14 14:31
 **/
@Data
public class OutstandingTree {
    private Integer id;

    private Long treeId;

    private LocalDateTime createTime;

    private LocalDateTime updateTime;
}
